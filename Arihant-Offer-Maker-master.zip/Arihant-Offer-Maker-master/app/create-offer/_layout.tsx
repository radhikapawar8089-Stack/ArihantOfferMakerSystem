import { Stack } from 'expo-router';

/**
 * Stack layout for the offer creation flow:
 * type → product → details → preview → share
 */
export default function CreateOfferLayout() {
  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen name="type" />
      <Stack.Screen name="product" />
      <Stack.Screen name="details" />
      <Stack.Screen name="preview" />
      <Stack.Screen name="share" />
    </Stack>
  );
}
