import React from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  Share,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { AppHeader } from '../../src/components/ui/AppHeader';
import { PrimaryButton } from '../../src/components/ui/PrimaryButton';
import { OfferPreviewCard } from '../../src/components/offer/OfferPreviewCard';
import { Colors } from '../../src/constants/Colors';
import { Typography } from '../../src/constants/Typography';
import { Spacing, Layout } from '../../src/constants/Layout';
import { useOfferStore } from '../../src/store/offerStore';
import { buildWhatsAppMessage, shareViaWhatsApp } from '../../src/services/whatsapp';
import type { Offer } from '../../src/types/offer';

export default function OfferPreviewScreen() {
  const router = useRouter();
  const { draft, resetDraft } = useOfferStore();

  // Cast the draft to a partial Offer for preview display
  const previewOffer = {
    id: 'preview',
    type: draft.offerType ?? 'daily',
    status: 'draft' as const,
    title: draft.title ?? '',
    description: draft.description ?? '',
    originalPrice: draft.originalPrice ?? 0,
    offerPrice: draft.offerPrice ?? 0,
    product: draft.product ?? null,
    productImage: draft.product?.imageUri,
    validFrom: new Date().toISOString(),
    validUntil: new Date(Date.now() + (draft.validityDays ?? 7) * 86400000).toISOString(),
    createdAt: new Date().toISOString(),
    sentCount: 0,
    openedCount: 0,
  } as unknown as Offer;

  const handleShareWhatsApp = async () => {
    const message = buildWhatsAppMessage(previewOffer);
    await shareViaWhatsApp(message);
  };

  const handleSendToCustomers = () => {
    router.push('/create-offer/share');
  };

  const handleSaveDraft = () => {
    // TODO: persist draft to local storage / backend
    Alert.alert('Saved', 'Your offer has been saved as a draft.', [
      { text: 'OK', onPress: () => router.replace('/(tabs)') },
    ]);
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <AppHeader
        title="Offer Preview"
        showBack={true}
        onLeftPress={() => router.back()}
      />

      <ScrollView contentContainerStyle={styles.scroll}>
        <Text style={styles.subtitle}>This is how your offer will look to customers</Text>
        <OfferPreviewCard offer={previewOffer} />
        <View style={styles.spacer} />
      </ScrollView>

      {/* Action bar */}
      <View style={styles.actions}>
        <PrimaryButton
          label="Send to Customers"
          variant="whatsapp"
          onPress={handleSendToCustomers}
          icon="📤"
          style={styles.actionBtn}
        />
        <View style={styles.secondaryRow}>
          <PrimaryButton
            label="Share via WhatsApp"
            variant="outline"
            onPress={handleShareWhatsApp}
            icon="💬"
            style={styles.halfBtn}
          />
          <PrimaryButton
            label="Save as Draft"
            variant="ghost"
            onPress={handleSaveDraft}
            style={styles.halfBtn}
          />
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.background },
  scroll: { padding: Layout.marginMobile, paddingBottom: 16 },
  subtitle: { ...Typography.bodyMd, color: Colors.secondary, marginBottom: Spacing.lg, textAlign: 'center' },
  spacer: { height: Spacing.xl },

  actions: {
    padding: Layout.marginMobile,
    paddingBottom: 24,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: Colors.outlineVariant,
    backgroundColor: Colors.background,
    gap: Spacing.sm,
  },
  actionBtn: { width: '100%' },
  secondaryRow: { flexDirection: 'row', gap: Spacing.sm },
  halfBtn: { flex: 1 },
});
