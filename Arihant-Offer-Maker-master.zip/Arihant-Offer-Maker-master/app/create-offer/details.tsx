import React from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TextInput,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { AppHeader } from '../../src/components/ui/AppHeader';
import { PrimaryButton } from '../../src/components/ui/PrimaryButton';
import { OfferPreviewCard } from '../../src/components/offer/OfferPreviewCard';
import { Colors } from '../../src/constants/Colors';
import { Typography } from '../../src/constants/Typography';
import { BorderRadius, Spacing, Layout } from '../../src/constants/Layout';
import { createOfferSchema, type CreateOfferFormData } from '../../src/utils/validation';
import { useOfferStore } from '../../src/store/offerStore';
import { formatRupees } from '../../src/utils/currency';

export default function CreateOfferDetailsScreen() {
  const router = useRouter();
  const { draft, setFormFields } = useOfferStore();

  const { control, handleSubmit, watch, formState: { errors } } = useForm<CreateOfferFormData>({
    resolver: zodResolver(createOfferSchema),
    defaultValues: {
      title: draft.title ?? '',
      description: draft.description ?? '',
      originalPrice: draft.originalPrice?.toString() ?? '',
      offerPrice: draft.offerPrice?.toString() ?? '',
      validityDays: draft.validityDays?.toString() ?? '7',
    },
  });

  const watchedValues = watch();

  // Live preview offer (partial draft)
  const previewOffer = {
    ...draft,
    title: watchedValues.title || draft.product?.name || 'Offer Title',
    description: watchedValues.description || '',
    originalPrice: Number(watchedValues.originalPrice) || 0,
    offerPrice: Number(watchedValues.offerPrice) || 0,
  };

  const onSave = (data: CreateOfferFormData) => {
    setFormFields({
      title: data.title,
      description: data.description ?? '',
      originalPrice: Number(data.originalPrice),
      offerPrice: Number(data.offerPrice),
      validityDays: Number(data.validityDays ?? '7'),
    });
    router.push('/create-offer/preview');
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <AppHeader
        title="Create Offer"
        showBack={true}
        onLeftPress={() => router.back()}
      />
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">

          {/* Product context chip */}
          {draft.product && (
            <View style={styles.productChip}>
              <Text style={styles.productChipLabel}>Product:</Text>
              <Text style={styles.productChipValue}>{draft.product.name}</Text>
            </View>
          )}

          {/* Live preview */}
          {(previewOffer.originalPrice > 0 && previewOffer.offerPrice > 0) && (
            <View style={styles.previewSection}>
              <Text style={styles.sectionLabel}>Live Preview</Text>
              <OfferPreviewCard offer={previewOffer as any} />
            </View>
          )}

          {/* Form */}
          <View style={styles.form}>
            <FormField
              label="Offer Title *"
              control={control}
              name="title"
              placeholder="e.g. Festive Saree Special"
              error={errors.title?.message}
            />
            <FormField
              label="Description"
              control={control}
              name="description"
              placeholder="Describe the offer for customers…"
              multiline
              error={errors.description?.message}
            />

            <View style={styles.priceRow}>
              <View style={{ flex: 1 }}>
                <FormField
                  label="Original Price (₹) *"
                  control={control}
                  name="originalPrice"
                  placeholder="e.g. 14999"
                  keyboardType="numeric"
                  error={errors.originalPrice?.message}
                />
              </View>
              <View style={{ flex: 1 }}>
                <FormField
                  label="Offer Price (₹) *"
                  control={control}
                  name="offerPrice"
                  placeholder="e.g. 11999"
                  keyboardType="numeric"
                  error={errors.offerPrice?.message}
                />
              </View>
            </View>

            <FormField
              label="Validity (days)"
              control={control}
              name="validityDays"
              placeholder="7"
              keyboardType="numeric"
              error={errors.validityDays?.message}
            />
          </View>

        </ScrollView>
      </KeyboardAvoidingView>

      <View style={styles.footer}>
        <PrimaryButton
          label="Preview Offer →"
          onPress={handleSubmit(onSave)}
          style={styles.cta}
        />
      </View>
    </SafeAreaView>
  );
}

// Reusable form field component
function FormField({
  label,
  control,
  name,
  placeholder,
  error,
  multiline,
  keyboardType,
}: {
  label: string;
  control: any;
  name: string;
  placeholder: string;
  error?: string;
  multiline?: boolean;
  keyboardType?: 'default' | 'numeric';
}) {
  return (
    <View style={fieldStyles.group}>
      <Text style={fieldStyles.label}>{label}</Text>
      <Controller
        control={control}
        name={name}
        render={({ field: { onChange, value } }) => (
          <TextInput
            style={[fieldStyles.input, multiline && fieldStyles.inputMulti]}
            placeholder={placeholder}
            placeholderTextColor={Colors.outlineVariant}
            onChangeText={onChange}
            value={value}
            multiline={multiline}
            keyboardType={keyboardType ?? 'default'}
          />
        )}
      />
      {error && <Text style={fieldStyles.error}>{error}</Text>}
    </View>
  );
}

const fieldStyles = StyleSheet.create({
  group: { gap: 6 },
  label: { ...Typography.labelLg, color: Colors.onSurfaceVariant, marginLeft: 4 },
  input: {
    height: 52,
    backgroundColor: Colors.surfaceContainerLowest,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    borderColor: Colors.outlineVariant,
    paddingHorizontal: Spacing.md,
    ...Typography.bodyMd,
    color: Colors.onSurface,
  },
  inputMulti: { height: 100, paddingTop: 14, textAlignVertical: 'top' },
  error: { ...Typography.labelSm, color: Colors.error, marginLeft: 4 },
});

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.background },
  scroll: { padding: Layout.marginMobile, paddingBottom: 16, gap: Spacing.lg },

  productChip: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.primaryContainer,
    borderRadius: BorderRadius.full,
    paddingHorizontal: Spacing.md,
    paddingVertical: 8,
    alignSelf: 'flex-start',
    gap: 6,
  },
  productChipLabel: { ...Typography.labelSm, color: Colors.primary },
  productChipValue: { ...Typography.labelLg, color: Colors.primary },

  previewSection: { gap: Spacing.sm },
  sectionLabel: { ...Typography.labelLg, color: Colors.secondary, marginLeft: 4 },

  form: { gap: Spacing.lg },
  priceRow: { flexDirection: 'row', gap: Spacing.md },

  footer: {
    padding: Layout.marginMobile,
    paddingBottom: 24,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: Colors.outlineVariant,
    backgroundColor: Colors.background,
  },
  cta: { width: '100%' },
});
