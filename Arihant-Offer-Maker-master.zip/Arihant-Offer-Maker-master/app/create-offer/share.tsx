import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  FlatList,
  Alert,
  TouchableOpacity,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { AppHeader } from '../../src/components/ui/AppHeader';
import { PrimaryButton } from '../../src/components/ui/PrimaryButton';
import { CustomerListItem } from '../../src/components/customer/CustomerListItem';
import { Colors } from '../../src/constants/Colors';
import { Typography } from '../../src/constants/Typography';
import { BorderRadius, Spacing, Layout } from '../../src/constants/Layout';
import { MOCK_CUSTOMERS, MOCK_TEMPLATES } from '../../src/services/mockData';
import { useOfferStore } from '../../src/store/offerStore';
import { useCustomerStore } from '../../src/store/customerStore';
import { buildWhatsAppMessage, sendWhatsAppToNumber } from '../../src/services/whatsapp';
import type { Offer } from '../../src/types/offer';

export default function ShareToWhatsAppScreen() {
  const router = useRouter();
  const { draft, resetDraft } = useOfferStore();
  const { selectedIds, toggle, selectAll, clearAll, isSelected } = useCustomerStore();
  const [isSending, setIsSending] = useState(false);

  // Build offer object from draft
  const offer = {
    id: 'share-preview',
    type: draft.offerType ?? 'daily',
    status: 'draft' as const,
    title: draft.title ?? '',
    description: draft.description ?? '',
    originalPrice: draft.originalPrice ?? 0,
    offerPrice: draft.offerPrice ?? 0,
    product: draft.product ?? null,
    validFrom: new Date().toISOString(),
    validUntil: new Date(Date.now() + (draft.validityDays ?? 7) * 86400000).toISOString(),
    createdAt: new Date().toISOString(),
    sentCount: 0,
    openedCount: 0,
  } as unknown as Offer;

  const message = buildWhatsAppMessage(offer, MOCK_TEMPLATES[0].id);
  const whatsappOptedIn = MOCK_CUSTOMERS.filter((c) => c.whatsappOptIn);
  const selectedCount = selectedIds.size;

  const handleSend = async () => {
    if (selectedCount === 0) {
      Alert.alert('No customers selected', 'Please select at least one customer.');
      return;
    }

    setIsSending(true);

    // Send to each selected customer sequentially
    const selected = whatsappOptedIn.filter((c) => isSelected(c.id));
    for (const customer of selected) {
      await sendWhatsAppToNumber(customer.phone, message);
    }

    setIsSending(false);
    clearAll();
    resetDraft();

    Alert.alert(
      'Offers Sent! 🎉',
      `Offer message sent to ${selectedCount} customer${selectedCount > 1 ? 's' : ''}.`,
      [{ text: 'Done', onPress: () => router.replace('/(tabs)') }],
    );
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <AppHeader
        title="Send to WhatsApp"
        showBack={true}
        onLeftPress={() => router.back()}
      />

      <ScrollView contentContainerStyle={styles.scroll} stickyHeaderIndices={[1]}>

        {/* Message preview */}
        <View style={styles.messageBox}>
          <Text style={styles.messageBoxTitle}>Message Preview</Text>
          <View style={styles.messageBubble}>
            <Text style={styles.messageText}>{message}</Text>
          </View>
        </View>

        {/* Sticky customer header */}
        <View style={styles.customerHeader}>
          <Text style={styles.customerTitle}>
            Select Customers ({selectedCount} selected)
          </Text>
          <TouchableOpacity
            onPress={() => {
              if (selectedCount === whatsappOptedIn.length) {
                clearAll();
              } else {
                selectAll(whatsappOptedIn.map((c) => c.id));
              }
            }}
          >
            <Text style={styles.selectAllText}>
              {selectedCount === whatsappOptedIn.length ? 'Deselect All' : 'Select All'}
            </Text>
          </TouchableOpacity>
        </View>

        {/* Customer list */}
        {whatsappOptedIn.length === 0 ? (
          <View style={styles.empty}>
            <Text style={styles.emptyText}>No customers with WhatsApp opt-in found.</Text>
          </View>
        ) : (
          whatsappOptedIn.map((customer) => (
            <CustomerListItem
              key={customer.id}
              customer={customer}
              mode="select"
              isSelected={isSelected(customer.id)}
              onToggle={() => toggle(customer.id)}
            />
          ))
        )}

      </ScrollView>

      {/* Footer CTA */}
      <View style={styles.footer}>
        <Text style={styles.footerHint}>
          {/* TODO: integrate WhatsApp Business API for bulk sending */}
          Each customer opens individually in WhatsApp. Bulk API requires WA Business approval.
        </Text>
        <PrimaryButton
          label={`Send to ${selectedCount} Customer${selectedCount !== 1 ? 's' : ''}`}
          variant="whatsapp"
          onPress={handleSend}
          isLoading={isSending}
          disabled={selectedCount === 0}
          icon="💬"
          style={styles.sendBtn}
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.background },
  scroll: { padding: Layout.marginMobile, paddingBottom: 16, gap: Spacing.lg },

  // Message preview
  messageBox: { gap: Spacing.sm },
  messageBoxTitle: { ...Typography.labelLg, color: Colors.onSurfaceVariant },
  messageBubble: {
    backgroundColor: Colors.primaryContainer,
    borderRadius: BorderRadius.xl,
    padding: Spacing.lg,
    borderTopLeftRadius: 4,
  },
  messageText: { ...Typography.bodyMd, color: Colors.onSurface, lineHeight: 22 },

  // Customer section header (sticky)
  customerHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: Colors.background,
    paddingVertical: Spacing.sm,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: Colors.outlineVariant,
  },
  customerTitle: { ...Typography.headlineMd, color: Colors.onSurface },
  selectAllText: { ...Typography.labelLg, color: Colors.primary },

  empty: { padding: Spacing.xl, alignItems: 'center' },
  emptyText: { ...Typography.bodyMd, color: Colors.secondary, textAlign: 'center' },

  footer: {
    padding: Layout.marginMobile,
    paddingBottom: 24,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: Colors.outlineVariant,
    backgroundColor: Colors.background,
    gap: Spacing.sm,
  },
  footerHint: { ...Typography.labelSm, color: Colors.secondary, textAlign: 'center' },
  sendBtn: { width: '100%' },
});
