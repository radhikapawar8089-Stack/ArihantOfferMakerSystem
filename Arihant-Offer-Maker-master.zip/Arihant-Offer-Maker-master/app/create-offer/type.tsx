import React from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { AppHeader } from '../../src/components/ui/AppHeader';
import { PrimaryButton } from '../../src/components/ui/PrimaryButton';
import { OfferTypeCard } from '../../src/components/offer/OfferTypeCard';
import { Colors } from '../../src/constants/Colors';
import { Typography } from '../../src/constants/Typography';
import { Spacing, Layout } from '../../src/constants/Layout';
import { OFFER_TYPE_CONFIGS } from '../../src/services/mockData';
import { useOfferStore } from '../../src/store/offerStore';
import type { OfferType } from '../../src/types/offer';

export default function SelectOfferTypeScreen() {
  const router = useRouter();
  const { draft, setOfferType } = useOfferStore();

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <AppHeader
        title="Select Offer Type"
        showBack={true}
        onLeftPress={() => router.back()}
      />
      <ScrollView contentContainerStyle={styles.scroll}>

        <View style={styles.intro}>
          <Text style={styles.introTitle}>What type of offer are you creating?</Text>
          <Text style={styles.introSub}>Choose the duration that best fits your promotion</Text>
        </View>

        <View style={styles.cards}>
          {OFFER_TYPE_CONFIGS.map((config) => (
            <OfferTypeCard
              key={config.type}
              config={config}
              isSelected={draft.offerType === config.type}
              onPress={() => setOfferType(config.type)}
            />
          ))}
        </View>

      </ScrollView>

      <View style={styles.footer}>
        <PrimaryButton
          label="Continue →"
          onPress={() => router.push('/create-offer/product')}
          disabled={!draft.offerType}
          style={styles.cta}
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.background },
  scroll: { padding: Layout.marginMobile, paddingBottom: 16, gap: 0 },

  intro: { marginBottom: Spacing.xl },
  introTitle: { ...Typography.headlineLg, color: Colors.onSurface, marginBottom: 6 },
  introSub: { ...Typography.bodyMd, color: Colors.secondary },

  cards: { gap: Spacing.md },

  footer: {
    padding: Layout.marginMobile,
    paddingBottom: 24,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: Colors.outlineVariant,
    backgroundColor: Colors.background,
  },
  cta: { width: '100%' },
});
