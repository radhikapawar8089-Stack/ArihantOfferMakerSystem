import React, { useState } from 'react';
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  TouchableOpacity,
  TextInput,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { AppHeader } from '../../src/components/ui/AppHeader';
import { PrimaryButton } from '../../src/components/ui/PrimaryButton';
import { ProductCard } from '../../src/components/product/ProductCard';
import { Colors } from '../../src/constants/Colors';
import { Typography } from '../../src/constants/Typography';
import { BorderRadius, Spacing, Layout } from '../../src/constants/Layout';
import { MOCK_PRODUCTS } from '../../src/services/mockData';
import { useOfferStore } from '../../src/store/offerStore';
import type { ProductCategory } from '../../src/types/product';

const CATEGORIES: ProductCategory[] = [
  'All Collections', 'Sarees', 'Kurtis', 'Dress Materials', 'Silk Specials', 'Mens Wear', 'Bridal',
];

export default function SelectProductScreen() {
  const router = useRouter();
  const { draft, setProduct } = useOfferStore();
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState<ProductCategory>('All Collections');

  const filtered = MOCK_PRODUCTS.filter((p) => {
    const matchCat = category === 'All Collections' || p.category === category;
    const matchSearch = p.name.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <AppHeader
        title="Select Product"
        showBack={true}
        onLeftPress={() => router.back()}
      />

      {/* Search */}
      <View style={styles.searchWrapper}>
        <TextInput
          style={styles.search}
          placeholder="Search products…"
          placeholderTextColor={Colors.outlineVariant}
          value={search}
          onChangeText={setSearch}
        />
      </View>

      {/* Category chips */}
      <FlatList
        horizontal
        showsHorizontalScrollIndicator={false}
        data={CATEGORIES}
        keyExtractor={(c) => c}
        contentContainerStyle={styles.chips}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={[styles.chip, category === item && styles.chipActive]}
            onPress={() => setCategory(item)}
          >
            <Text style={[styles.chipText, category === item && styles.chipTextActive]}>
              {item}
            </Text>
          </TouchableOpacity>
        )}
      />

      {/* Product grid */}
      <FlatList
        data={filtered}
        keyExtractor={(p) => p.id}
        numColumns={2}
        contentContainerStyle={styles.grid}
        columnWrapperStyle={styles.row}
        renderItem={({ item }) => (
          <View style={styles.gridItem}>
            <ProductCard
              product={item}
              isSelected={draft.product?.id === item.id}
              onSelect={() => setProduct(item)}
              size="standard"
            />
          </View>
        )}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Text style={styles.emptyText}>No products found</Text>
          </View>
        }
      />

      <View style={styles.footer}>
        {draft.product && (
          <Text style={styles.selected}>
            ✓  {draft.product.name} selected
          </Text>
        )}
        <PrimaryButton
          label="Continue →"
          onPress={() => router.push('/create-offer/details')}
          disabled={!draft.product}
          style={styles.cta}
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.background },

  searchWrapper: { padding: Layout.marginMobile, paddingBottom: 8 },
  search: {
    height: 48,
    backgroundColor: Colors.surfaceContainer,
    borderRadius: BorderRadius.lg,
    paddingHorizontal: Spacing.md,
    ...Typography.bodyMd,
    color: Colors.onSurface,
  },

  chips: { paddingHorizontal: Layout.marginMobile, gap: Spacing.sm, paddingBottom: 12 },
  chip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: BorderRadius.full,
    backgroundColor: Colors.surfaceContainer,
    borderWidth: 1,
    borderColor: Colors.outlineVariant,
  },
  chipActive: { backgroundColor: Colors.primaryContainer, borderColor: Colors.primary },
  chipText: { ...Typography.labelSm, color: Colors.secondary },
  chipTextActive: { color: Colors.primary, fontFamily: 'Manrope_700Bold' },

  grid: { paddingHorizontal: Layout.marginMobile, paddingBottom: 100 },
  row: { gap: Spacing.sm, marginBottom: Spacing.sm },
  gridItem: { flex: 1 },

  empty: { padding: Spacing.xxl, alignItems: 'center' },
  emptyText: { ...Typography.bodyMd, color: Colors.secondary },

  footer: {
    padding: Layout.marginMobile,
    paddingBottom: 24,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: Colors.outlineVariant,
    backgroundColor: Colors.background,
    gap: Spacing.sm,
  },
  selected: { ...Typography.labelLg, color: Colors.primary, textAlign: 'center' },
  cta: { width: '100%' },
});
