import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { loginSchema, otpSchema, type LoginFormData, type OtpFormData } from '../src/utils/validation';
import { useAuthStore } from '../src/store/authStore';
import { PrimaryButton } from '../src/components/ui/PrimaryButton';
import { Colors } from '../src/constants/Colors';
import { Typography } from '../src/constants/Typography';
import { BorderRadius, Spacing } from '../src/constants/Layout';

type Step = 'mobile' | 'otp';

export default function LoginScreen() {
  const router = useRouter();
  const [step, setStep] = useState<Step>('mobile');
  const { login, verifyOtp, isLoading } = useAuthStore();

  // OTP digit refs for auto-focus
  const otpRefs = [
    useRef<TextInput>(null),
    useRef<TextInput>(null),
    useRef<TextInput>(null),
    useRef<TextInput>(null),
  ];
  const [otpDigits, setOtpDigits] = useState(['', '', '', '']);

  const { control: mobileControl, handleSubmit: handleMobileSubmit, formState: { errors: mobileErrors } } =
    useForm<LoginFormData>({ resolver: zodResolver(loginSchema) });

  const onSendOtp = async (data: LoginFormData) => {
    await login(data.mobile);
    setStep('otp');
  };

  const onVerifyOtp = async () => {
    const otp = otpDigits.join('');
    const result = otpSchema.safeParse({ otp });
    if (!result.success) {
      Alert.alert('Invalid OTP', 'Please enter the 4-digit OTP sent to your phone.');
      return;
    }
    const success = await verifyOtp(otp);
    if (success) {
      router.replace('/(tabs)');
    } else {
      Alert.alert('Invalid OTP', 'The OTP you entered is incorrect. Please try again.');
      setOtpDigits(['', '', '', '']);
      otpRefs[0].current?.focus();
    }
  };

  const handleOtpChange = (value: string, index: number) => {
    const next = [...otpDigits];
    next[index] = value.replace(/\D/g, '').slice(-1);
    setOtpDigits(next);
    if (value && index < 3) {
      otpRefs[index + 1].current?.focus();
    }
  };

  const handleOtpKeyPress = (key: string, index: number) => {
    if (key === 'Backspace' && !otpDigits[index] && index > 0) {
      otpRefs[index - 1].current?.focus();
    }
  };

  return (
    <SafeAreaView style={styles.safe}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">

          {/* Brand header */}
          <View style={styles.header}>
            <View style={styles.logoBox}>
              <Text style={styles.logoIcon}>✦</Text>
            </View>
            <Text style={styles.brandName}>ARIHANT</Text>
          </View>

          {/* Welcome text */}
          <View style={styles.welcomeBlock}>
            <Text style={styles.welcomeTitle}>Welcome Back</Text>
            <Text style={styles.welcomeSub}>
              Enter your details to access your boutique dashboard
            </Text>
          </View>

          {/* Form */}
          <View style={styles.form}>
            {step === 'mobile' ? (
              <>
                {/* Mobile number */}
                <View style={styles.fieldGroup}>
                  <Text style={styles.label}>Mobile Number</Text>
                  <View style={styles.mobileRow}>
                    <View style={styles.countryCode}>
                      <Text style={styles.countryCodeText}>+91</Text>
                    </View>
                    <Controller
                      control={mobileControl}
                      name="mobile"
                      render={({ field: { onChange, value } }) => (
                        <TextInput
                          style={styles.mobileInput}
                          placeholder="00000 00000"
                          placeholderTextColor={Colors.outlineVariant}
                          keyboardType="phone-pad"
                          maxLength={10}
                          onChangeText={onChange}
                          value={value}
                          autoFocus
                        />
                      )}
                    />
                  </View>
                  {mobileErrors.mobile && (
                    <Text style={styles.error}>{mobileErrors.mobile.message}</Text>
                  )}
                </View>

                <PrimaryButton
                  label="Send OTP →"
                  onPress={handleMobileSubmit(onSendOtp)}
                  isLoading={isLoading}
                  style={styles.btn}
                />
              </>
            ) : (
              <>
                {/* OTP input */}
                <View style={styles.fieldGroup}>
                  <View style={styles.otpHeader}>
                    <Text style={styles.label}>One-Time Password</Text>
                    <TouchableOpacity onPress={() => setStep('mobile')}>
                      <Text style={styles.resend}>Resend OTP</Text>
                    </TouchableOpacity>
                  </View>
                  <View style={styles.otpRow}>
                    {otpDigits.map((digit, i) => (
                      <TextInput
                        key={i}
                        ref={otpRefs[i]}
                        style={[styles.otpBox, digit ? styles.otpBoxFilled : null]}
                        value={digit}
                        onChangeText={(v) => handleOtpChange(v, i)}
                        onKeyPress={({ nativeEvent }) => handleOtpKeyPress(nativeEvent.key, i)}
                        keyboardType="numeric"
                        maxLength={1}
                        textAlign="center"
                        selectTextOnFocus
                        autoFocus={i === 0}
                      />
                    ))}
                  </View>
                </View>

                <PrimaryButton
                  label="Sign In →"
                  onPress={onVerifyOtp}
                  isLoading={isLoading}
                  style={styles.btn}
                />

                <TouchableOpacity onPress={() => setStep('mobile')} style={styles.backBtn}>
                  <Text style={styles.backText}>← Change mobile number</Text>
                </TouchableOpacity>
              </>
            )}
          </View>

          {/* Decorative divider */}
          <View style={styles.divider}>
            <View style={styles.line} />
            <Text style={styles.dividerText}>PREMIUM ETHNIC WEAR</Text>
            <View style={styles.line} />
          </View>

          {/* Fabric teaser card (mirrors Stitch login screen) */}
          <View style={styles.teaserCard}>
            <View style={styles.teaserGradient}>
              <Text style={styles.teaserLabel}>NEW ARRIVALS</Text>
              <Text style={styles.teaserTitle}>Explore Festive 2024</Text>
            </View>
          </View>

        </ScrollView>
      </KeyboardAvoidingView>

      {/* Footer */}
      <View style={styles.footer}>
        <Text style={styles.footerText}>🔒  Secure Staff Login</Text>
        <Text style={styles.footerSub}>Arihant Cloth Store © 2024</Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.background },
  scroll: { flexGrow: 1, padding: Spacing.lg, paddingBottom: 32 },

  // Brand header (mirrors Stitch logo block)
  header: { alignItems: 'center', paddingTop: Spacing.xxl, marginBottom: Spacing.lg },
  logoBox: {
    width: 56,
    height: 56,
    borderRadius: BorderRadius.lg,
    backgroundColor: Colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Spacing.sm,
  },
  logoIcon: { fontSize: 28, color: Colors.onPrimary },
  brandName: {
    ...Typography.headlineMd,
    color: Colors.primary,
    letterSpacing: 6,
  },

  // Welcome
  welcomeBlock: { alignItems: 'center', marginBottom: Spacing.xl },
  welcomeTitle: { ...Typography.headlineLg, color: Colors.onSurface, marginBottom: 6 },
  welcomeSub: { ...Typography.bodyMd, color: Colors.secondary, textAlign: 'center' },

  // Form
  form: { gap: Spacing.lg },
  fieldGroup: { gap: Spacing.sm },
  label: { ...Typography.labelLg, color: Colors.onSurfaceVariant, marginLeft: 4 },

  // Mobile input
  mobileRow: {
    flexDirection: 'row',
    borderBottomWidth: 2,
    borderBottomColor: Colors.outlineVariant,
    height: 56,
    alignItems: 'center',
  },
  countryCode: {
    paddingRight: 12,
    marginRight: 8,
    borderRightWidth: 1,
    borderRightColor: Colors.outlineVariant,
  },
  countryCodeText: { ...Typography.headlineMd, color: Colors.secondary, fontSize: 18 },
  mobileInput: {
    flex: 1,
    ...Typography.headlineMd,
    fontSize: 22,
    color: Colors.onSurface,
    paddingVertical: 0,
  },
  error: { ...Typography.labelSm, color: Colors.error, marginLeft: 4 },

  // OTP
  otpHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  resend: { ...Typography.labelLg, color: Colors.primary },
  otpRow: { flexDirection: 'row', gap: Spacing.sm, height: 64 },
  otpBox: {
    flex: 1,
    height: 64,
    backgroundColor: Colors.surfaceContainerLowest,
    borderBottomWidth: 2,
    borderBottomColor: Colors.outlineVariant,
    borderRadius: 8,
    ...Typography.headlineLg,
    color: Colors.onSurface,
    fontSize: 28,
  },
  otpBoxFilled: { borderBottomColor: Colors.primary },

  btn: { width: '100%', marginTop: Spacing.sm },
  backBtn: { alignItems: 'center', paddingVertical: 8 },
  backText: { ...Typography.labelLg, color: Colors.secondary },

  // Divider
  divider: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: Spacing.xl,
    marginBottom: Spacing.lg,
    gap: Spacing.sm,
  },
  line: { flex: 1, height: StyleSheet.hairlineWidth, backgroundColor: Colors.outlineVariant },
  dividerText: { ...Typography.labelSm, color: Colors.secondary, letterSpacing: 2 },

  // Teaser card (placeholder for fabric image)
  teaserCard: {
    height: 160,
    borderRadius: BorderRadius.xxl,
    backgroundColor: Colors.primaryContainer,
    overflow: 'hidden',
    justifyContent: 'flex-end',
  },
  teaserGradient: {
    padding: Spacing.lg,
    backgroundColor: Colors.primary + 'CC',
  },
  teaserLabel: { ...Typography.labelSm, color: Colors.onPrimary, opacity: 0.8, letterSpacing: 2, marginBottom: 4 },
  teaserTitle: { ...Typography.headlineMd, color: Colors.onPrimary },

  // Footer
  footer: { alignItems: 'center', padding: Spacing.lg, gap: 4 },
  footerText: { ...Typography.labelSm, color: Colors.secondary },
  footerSub: { ...Typography.labelSm, color: Colors.outlineVariant },
});
