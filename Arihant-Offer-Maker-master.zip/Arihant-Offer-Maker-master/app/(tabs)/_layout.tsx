import { Tabs } from 'expo-router';
import { BottomTabBar } from '../../src/components/ui/BottomTabBar';

/**
 * Bottom-tab group layout.
 * Tabs: Home (Dashboard) | Offers (History) | Customers | Settings
 */
export default function TabLayout() {
  return (
    <Tabs
      tabBar={(props) => <BottomTabBar {...props} />}
      screenOptions={{ headerShown: false }}
    >
      <Tabs.Screen name="index" />
      <Tabs.Screen name="history" />
      <Tabs.Screen name="customers" />
      <Tabs.Screen name="settings" />
    </Tabs>
  );
}
