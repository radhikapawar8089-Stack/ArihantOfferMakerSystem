import React from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { AppHeader } from '../../src/components/ui/AppHeader';
import { OfferCard } from '../../src/components/offer/OfferCard';
import { Colors } from '../../src/constants/Colors';
import { Typography } from '../../src/constants/Typography';
import { BorderRadius, Spacing, Layout } from '../../src/constants/Layout';
import { MOCK_DASHBOARD_STATS, MOCK_OFFERS } from '../../src/services/mockData';
import { useAuthStore } from '../../src/store/authStore';

export default function DashboardScreen() {
  const router = useRouter();
  const user = useAuthStore((s) => s.user);
  const recentOffers = MOCK_OFFERS.slice(0, 3);
  const stats = MOCK_DASHBOARD_STATS;

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good Morning';
    if (hour < 17) return 'Good Afternoon';
    return 'Good Evening';
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <AppHeader
        title="Arihant Offer Maker"
        showBack={false}
        rightElement={
          <TouchableOpacity style={styles.avatarBtn}>
            <Text style={styles.avatarText}>
              {(user?.name ?? 'Staff').slice(0, 1).toUpperCase()}
            </Text>
          </TouchableOpacity>
        }
      />

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>

        {/* Greeting */}
        <View style={styles.greeting}>
          <Text style={styles.greetText}>{getGreeting()}, {user?.name ?? 'Staff'} 👋</Text>
          <Text style={styles.greetSub}>Here's today's overview</Text>
        </View>

        {/* Bento stats grid */}
        <View style={styles.bentoGrid}>
          <TouchableOpacity style={[styles.bentoCard, styles.bentoLarge]}>
            <Text style={styles.bentoLabel}>Offers Sent This Month</Text>
            <Text style={styles.bentoValue}>{stats.offersSentThisMonth}</Text>
            <Text style={styles.bentoDelta}>↑ {stats.monthlyGrowth}% vs last month</Text>
          </TouchableOpacity>

          <View style={styles.bentoColumn}>
            <TouchableOpacity style={[styles.bentoCard, styles.bentoSmall]}>
              <Text style={styles.bentoLabel}>Open Rate</Text>
              <Text style={styles.bentoValueSm}>{stats.averageOpenRate}%</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.bentoCard, styles.bentoSmall]}>
              <Text style={styles.bentoLabel}>Active Now</Text>
              <Text style={styles.bentoValueSm}>{stats.activeOffers}</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Secondary stats row */}
        <View style={styles.statsRow}>
          {[
            { label: 'Customers Reached', value: stats.customersReached.toString() },
            { label: 'Scheduled', value: stats.scheduledOffers.toString() },
            { label: 'Drafts', value: stats.draftOffers.toString() },
          ].map((s) => (
            <View key={s.label} style={styles.statChip}>
              <Text style={styles.statChipValue}>{s.value}</Text>
              <Text style={styles.statChipLabel}>{s.label}</Text>
            </View>
          ))}
        </View>

        {/* Quick Actions */}
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Quick Actions</Text>
        </View>
        <View style={styles.qaRow}>
          <TouchableOpacity
            style={[styles.qaCard, styles.qaCardPrimary]}
            onPress={() => router.push('/create-offer/type')}
          >
            <Text style={styles.qaIcon}>✦</Text>
            <Text style={styles.qaLabelPrimary}>Create Offer</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.qaCard}
            onPress={() => router.push('/(tabs)/history')}
          >
            <Text style={styles.qaIcon}>📋</Text>
            <Text style={styles.qaLabel}>View Offers</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.qaCard}
            onPress={() => router.push('/(tabs)/customers')}
          >
            <Text style={styles.qaIcon}>👥</Text>
            <Text style={styles.qaLabel}>Customers</Text>
          </TouchableOpacity>
        </View>

        {/* Recent Offers */}
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Recent Offers</Text>
          <TouchableOpacity onPress={() => router.push('/(tabs)/history')}>
            <Text style={styles.viewAll}>View All →</Text>
          </TouchableOpacity>
        </View>

        {recentOffers.map((offer) => (
          <OfferCard
            key={offer.id}
            offer={offer}
            onDuplicate={() => router.push('/create-offer/type')}
          />
        ))}

      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.background },
  scroll: { padding: Layout.marginMobile, paddingBottom: 96, gap: 0 },

  // Avatar
  avatarBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.brandRed,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: { ...Typography.labelLg, color: '#fff', fontFamily: 'Manrope_700Bold' },

  // Greeting
  greeting: { marginBottom: Spacing.lg },
  greetText: { ...Typography.headlineMd, color: Colors.onSurface },
  greetSub: { ...Typography.bodyMd, color: Colors.secondary, marginTop: 2 },

  // Bento grid
  bentoGrid: { flexDirection: 'row', gap: Spacing.md, marginBottom: Spacing.md },
  bentoCard: {
    backgroundColor: Colors.surfaceContainer,
    borderRadius: BorderRadius.xxl,
    padding: Spacing.lg,
  },
  bentoLarge: { flex: 2, backgroundColor: Colors.primaryContainer },
  bentoColumn: { flex: 1, gap: Spacing.md },
  bentoSmall: { flex: 1 },
  bentoLabel: { ...Typography.labelSm, color: Colors.secondary, marginBottom: Spacing.xs },
  bentoValue: { ...Typography.headlineXl, color: Colors.primary, lineHeight: 52 },
  bentoValueSm: { ...Typography.headlineLg, color: Colors.onSurface, lineHeight: 36 },
  bentoDelta: { ...Typography.labelSm, color: Colors.primary, marginTop: Spacing.xs },

  // Stats row
  statsRow: {
    flexDirection: 'row',
    gap: Spacing.sm,
    marginBottom: Spacing.xl,
  },
  statChip: {
    flex: 1,
    backgroundColor: Colors.surfaceContainer,
    borderRadius: BorderRadius.lg,
    padding: Spacing.md,
    alignItems: 'center',
  },
  statChipValue: { ...Typography.headlineMd, color: Colors.onSurface },
  statChipLabel: { ...Typography.labelSm, color: Colors.secondary, textAlign: 'center', marginTop: 2 },

  // Section header
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: Spacing.md,
  },
  sectionTitle: { ...Typography.headlineMd, color: Colors.onSurface },
  viewAll: { ...Typography.labelLg, color: Colors.primary },

  // Quick actions
  qaRow: { flexDirection: 'row', gap: Spacing.sm, marginBottom: Spacing.xl },
  qaCard: {
    flex: 1,
    backgroundColor: Colors.surfaceContainer,
    borderRadius: BorderRadius.xl,
    padding: Spacing.md,
    alignItems: 'center',
    gap: 6,
  },
  qaCardPrimary: { backgroundColor: Colors.primary },
  qaIcon: { fontSize: 22 },
  qaLabel: { ...Typography.labelSm, color: Colors.onSurface, textAlign: 'center' },
  qaLabelPrimary: { ...Typography.labelSm, color: Colors.onPrimary, textAlign: 'center' },
});
