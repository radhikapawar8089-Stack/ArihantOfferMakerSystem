import React, { useState } from 'react';
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  TouchableOpacity,
  TextInput,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { AppHeader } from '../../src/components/ui/AppHeader';
import { CustomerListItem } from '../../src/components/customer/CustomerListItem';
import { Colors } from '../../src/constants/Colors';
import { Typography } from '../../src/constants/Typography';
import { BorderRadius, Spacing, Layout } from '../../src/constants/Layout';
import { MOCK_CUSTOMERS } from '../../src/services/mockData';
import type { CustomerSegment } from '../../src/types/customer';

const SEGMENT_FILTERS: { key: CustomerSegment | 'All'; label: string }[] = [
  { key: 'All', label: 'All' },
  { key: 'Bridal Exclusive', label: 'Bridal' },
  { key: 'Women Ethnic', label: 'Women' },
  { key: "Men's Wear", label: 'Men' },
];

export default function CustomersScreen() {
  const [search, setSearch] = useState('');
  const [segment, setSegment] = useState<CustomerSegment | 'All'>('All');

  const filtered = MOCK_CUSTOMERS.filter((c) => {
    const matchSeg = segment === 'All' || c.segment === segment;
    const matchSearch = c.name.toLowerCase().includes(search.toLowerCase()) ||
      c.phone.includes(search);
    return matchSeg && matchSearch;
  });

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <AppHeader title="Customers" showBack={false} />

      {/* Search */}
      <View style={styles.searchWrapper}>
        <TextInput
          style={styles.searchInput}
          placeholder="Search by name or mobile…"
          placeholderTextColor={Colors.outlineVariant}
          value={search}
          onChangeText={setSearch}
        />
      </View>

      {/* Segment chips */}
      <View style={styles.chipsWrapper}>
        <FlatList
          horizontal
          showsHorizontalScrollIndicator={false}
          data={SEGMENT_FILTERS}
          keyExtractor={(i) => i.key}
          contentContainerStyle={styles.chips}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={[styles.chip, segment === item.key && styles.chipActive]}
              onPress={() => setSegment(item.key as CustomerSegment | 'All')}
            >
              <Text style={[styles.chipText, segment === item.key && styles.chipTextActive]}>
                {item.label}
              </Text>
            </TouchableOpacity>
          )}
        />
      </View>

      {/* Count */}
      <View style={styles.countRow}>
        <Text style={styles.countText}>{filtered.length} customers</Text>
      </View>

      <FlatList
        data={filtered}
        keyExtractor={(c) => c.id}
        contentContainerStyle={styles.list}
        renderItem={({ item }) => (
          <CustomerListItem customer={item} mode="card" onToggle={() => {}} />
        )}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Text style={styles.emptyText}>No customers found</Text>
          </View>
        }
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.background },

  searchWrapper: { padding: Layout.marginMobile, paddingBottom: 8 },
  searchInput: {
    height: 48,
    backgroundColor: Colors.surfaceContainer,
    borderRadius: BorderRadius.lg,
    paddingHorizontal: Spacing.md,
    ...Typography.bodyMd,
    color: Colors.onSurface,
  },

  chipsWrapper: { marginBottom: 8 },
  chips: { paddingHorizontal: Layout.marginMobile, gap: Spacing.sm },
  chip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: BorderRadius.full,
    backgroundColor: Colors.surfaceContainer,
    borderWidth: 1,
    borderColor: Colors.outlineVariant,
  },
  chipActive: {
    backgroundColor: Colors.primaryContainer,
    borderColor: Colors.primary,
  },
  chipText: { ...Typography.labelSm, color: Colors.secondary },
  chipTextActive: { color: Colors.primary, fontFamily: 'Manrope_700Bold' },

  countRow: { paddingHorizontal: Layout.marginMobile, paddingBottom: 8 },
  countText: { ...Typography.labelSm, color: Colors.secondary },

  list: { paddingHorizontal: Layout.marginMobile, paddingBottom: 96, gap: Spacing.sm },
  empty: { padding: Spacing.xxl, alignItems: 'center' },
  emptyText: { ...Typography.bodyMd, color: Colors.secondary },
});
