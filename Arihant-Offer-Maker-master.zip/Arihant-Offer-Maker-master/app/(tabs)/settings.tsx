import React from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Switch,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { AppHeader } from '../../src/components/ui/AppHeader';
import { Colors } from '../../src/constants/Colors';
import { Typography } from '../../src/constants/Typography';
import { BorderRadius, Spacing, Layout } from '../../src/constants/Layout';
import { MOCK_TEMPLATES } from '../../src/services/mockData';
import { useAuthStore } from '../../src/store/authStore';

export default function SettingsScreen() {
  const router = useRouter();
  const { user, logout } = useAuthStore();

  const handleLogout = () => {
    logout();
    router.replace('/login');
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <AppHeader title="Settings" showBack={false} />
      <ScrollView contentContainerStyle={styles.scroll}>

        {/* Shop profile */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Shop Profile</Text>
          <View style={styles.card}>
            <View style={styles.profileRow}>
              <View style={styles.avatar}>
                <Text style={styles.avatarText}>A</Text>
              </View>
              <View style={styles.profileInfo}>
                <Text style={styles.shopName}>Arihant Cloth Store</Text>
                <Text style={styles.shopSub}>Premium ethnic wear boutique</Text>
              </View>
            </View>
            <View style={styles.divider} />
            <SettingRow label="Store Name" value="Arihant Cloth Store" />
            <SettingRow label="City" value="Pune, Maharashtra" />
            <SettingRow label="Staff Mobile" value={user?.mobile ?? '—'} />
            <SettingRow label="Staff Name" value={user?.name ?? 'Staff'} />
          </View>
        </View>

        {/* WhatsApp Templates */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>WhatsApp Templates</Text>
          <Text style={styles.sectionSub}>
            Templates used when generating offer messages.{'\n'}
            {/* TODO: integrate WhatsApp Business API template management */}
          </Text>
          <View style={styles.card}>
            {MOCK_TEMPLATES.map((t, i) => (
              <View key={t.id}>
                <View style={styles.templateRow}>
                  <View style={styles.templateDot} />
                  <View style={styles.templateInfo}>
                    <Text style={styles.templateName}>{t.name}</Text>
                    <Text style={styles.templatePreview} numberOfLines={2}>{t.body}</Text>
                  </View>
                </View>
                {i < MOCK_TEMPLATES.length - 1 && <View style={styles.divider} />}
              </View>
            ))}
          </View>
        </View>

        {/* Notifications */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Notifications</Text>
          <View style={styles.card}>
            <ToggleRow label="Offer Delivery Reports" value={true} />
            <View style={styles.divider} />
            <ToggleRow label="Scheduled Offer Reminders" value={true} />
            <View style={styles.divider} />
            <ToggleRow label="New Customer Alerts" value={false} />
          </View>
        </View>

        {/* About */}
        <View style={styles.section}>
          <View style={styles.card}>
            <SettingRow label="App Version" value="1.0.0" />
            <View style={styles.divider} />
            <SettingRow label="Support" value="9876543210" />
          </View>
        </View>

        {/* Logout */}
        <TouchableOpacity style={styles.logoutBtn} onPress={handleLogout}>
          <Text style={styles.logoutText}>Log Out</Text>
        </TouchableOpacity>

      </ScrollView>
    </SafeAreaView>
  );
}

function SettingRow({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.settingRow}>
      <Text style={styles.settingLabel}>{label}</Text>
      <Text style={styles.settingValue}>{value}</Text>
    </View>
  );
}

function ToggleRow({ label, value }: { label: string; value: boolean }) {
  const [enabled, setEnabled] = React.useState(value);
  return (
    <View style={styles.settingRow}>
      <Text style={styles.settingLabel}>{label}</Text>
      <Switch
        value={enabled}
        onValueChange={setEnabled}
        trackColor={{ false: Colors.outlineVariant, true: Colors.primary }}
        thumbColor={Colors.onPrimary}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.background },
  scroll: { padding: Layout.marginMobile, paddingBottom: 96, gap: Spacing.lg },

  section: { gap: Spacing.sm },
  sectionTitle: { ...Typography.headlineMd, color: Colors.onSurface },
  sectionSub: { ...Typography.labelSm, color: Colors.secondary, lineHeight: 18 },

  card: {
    backgroundColor: Colors.surfaceContainerLowest,
    borderRadius: BorderRadius.xxl,
    overflow: 'hidden',
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: Colors.outlineVariant,
  },

  profileRow: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: Spacing.lg,
    gap: Spacing.md,
  },
  avatar: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: Colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: { ...Typography.headlineMd, color: Colors.onPrimary },
  profileInfo: { flex: 1 },
  shopName: { ...Typography.headlineMd, color: Colors.onSurface },
  shopSub: { ...Typography.bodyMd, color: Colors.secondary, marginTop: 2 },

  settingRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: Spacing.lg,
  },
  settingLabel: { ...Typography.bodyMd, color: Colors.onSurface },
  settingValue: { ...Typography.bodyMd, color: Colors.secondary },

  divider: { height: StyleSheet.hairlineWidth, backgroundColor: Colors.outlineVariant, marginHorizontal: Spacing.lg },

  // Templates
  templateRow: { flexDirection: 'row', padding: Spacing.lg, gap: Spacing.sm },
  templateDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: Colors.primary,
    marginTop: 6,
  },
  templateInfo: { flex: 1 },
  templateName: { ...Typography.labelLg, color: Colors.onSurface, marginBottom: 4 },
  templatePreview: { ...Typography.labelSm, color: Colors.secondary, lineHeight: 18 },

  // Logout
  logoutBtn: {
    height: 52,
    backgroundColor: Colors.errorContainer,
    borderRadius: BorderRadius.xl,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: Spacing.sm,
  },
  logoutText: { ...Typography.labelLg, color: Colors.error, fontFamily: 'Manrope_700Bold' },
});
