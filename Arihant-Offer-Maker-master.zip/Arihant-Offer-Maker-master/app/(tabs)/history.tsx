import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  FlatList,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { AppHeader } from '../../src/components/ui/AppHeader';
import { OfferCard } from '../../src/components/offer/OfferCard';
import { PrimaryButton } from '../../src/components/ui/PrimaryButton';
import { Colors } from '../../src/constants/Colors';
import { Typography } from '../../src/constants/Typography';
import { BorderRadius, Spacing, Layout } from '../../src/constants/Layout';
import { MOCK_OFFERS } from '../../src/services/mockData';
import type { OfferStatus } from '../../src/types/offer';

type TabFilter = 'sent' | 'scheduled' | 'draft';

const TABS: { key: TabFilter; label: string }[] = [
  { key: 'sent', label: 'Sent' },
  { key: 'scheduled', label: 'Scheduled' },
  { key: 'draft', label: 'Drafts' },
];

export default function OfferHistoryScreen() {
  const router = useRouter();
  const [activeTab, setActiveTab] = useState<TabFilter>('sent');

  const filtered = MOCK_OFFERS.filter((o) => {
    if (activeTab === 'sent') return o.status === 'sent' || o.status === 'active' || o.status === 'ended';
    return o.status === activeTab;
  });

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <AppHeader
        title="Offer History"
        showBack={false}
      />

      {/* Tabs */}
      <View style={styles.tabs}>
        {TABS.map((t) => (
          <TouchableOpacity
            key={t.key}
            style={[styles.tab, activeTab === t.key && styles.tabActive]}
            onPress={() => setActiveTab(t.key)}
          >
            <Text style={[styles.tabLabel, activeTab === t.key && styles.tabLabelActive]}>
              {t.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {filtered.length === 0 ? (
        <View style={styles.empty}>
          <Text style={styles.emptyIcon}>📋</Text>
          <Text style={styles.emptyTitle}>No {activeTab} offers</Text>
          <Text style={styles.emptySub}>Tap "Create Offer" to build a new promotional offer</Text>
          <PrimaryButton
            label="Create Offer"
            onPress={() => router.push('/create-offer/type')}
            style={styles.emptyBtn}
          />
        </View>
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.list}
          renderItem={({ item }) => (
            <OfferCard
              offer={item}
              onDuplicate={() => router.push('/create-offer/type')}
            />
          )}
        />
      )}

      {/* FAB */}
      <TouchableOpacity
        style={styles.fab}
        onPress={() => router.push('/create-offer/type')}
      >
        <Text style={styles.fabText}>＋</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.background },

  // Tabs
  tabs: {
    flexDirection: 'row',
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: Colors.outlineVariant,
    backgroundColor: Colors.surfaceContainerLowest,
  },
  tab: {
    flex: 1,
    paddingVertical: 14,
    alignItems: 'center',
  },
  tabActive: {
    borderBottomWidth: 2,
    borderBottomColor: Colors.primary,
  },
  tabLabel: { ...Typography.labelLg, color: Colors.secondary },
  tabLabelActive: { color: Colors.primary, fontFamily: 'Manrope_700Bold' },

  list: { padding: Layout.marginMobile, gap: Spacing.md, paddingBottom: 96 },

  // Empty state
  empty: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: Layout.marginMobile,
    gap: Spacing.md,
  },
  emptyIcon: { fontSize: 48 },
  emptyTitle: { ...Typography.headlineMd, color: Colors.onSurface },
  emptySub: { ...Typography.bodyMd, color: Colors.secondary, textAlign: 'center' },
  emptyBtn: { marginTop: Spacing.sm },

  // FAB
  fab: {
    position: 'absolute',
    right: Layout.marginMobile,
    bottom: 80,
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: Colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  fabText: { fontSize: 24, color: Colors.onPrimary, lineHeight: 28 },
});
