// Spacing & layout constants from DESIGN.md

export const Spacing = {
  base: 8,
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24, // gutter
  xl: 32,
  xxl: 48, // margin-desktop
} as const;

export const BorderRadius = {
  sm: 4,
  DEFAULT: 8,
  lg: 12,
  xl: 16,
  xxl: 24,
  full: 9999,
} as const;

export const Layout = {
  headerHeight: 64,
  bottomTabHeight: 64,
  containerMaxWidth: 1280,
  marginMobile: 16,
  marginDesktop: 48,
  gutter: 24,
} as const;
