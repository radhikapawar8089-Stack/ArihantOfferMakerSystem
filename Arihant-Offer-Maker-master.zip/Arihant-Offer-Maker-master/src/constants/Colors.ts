// Design tokens from heritage_refined/DESIGN.md
// Direct mapping from Stitch color system

export const Colors = {
  // Surface hierarchy
  surface: '#f9f9f9',
  surfaceDim: '#dadada',
  surfaceBright: '#f9f9f9',
  surfaceContainerLowest: '#ffffff',
  surfaceContainerLow: '#f3f3f4',
  surfaceContainer: '#eeeeee',
  surfaceContainerHigh: '#e8e8e8',
  surfaceContainerHighest: '#e2e2e2',

  // On-surface
  onSurface: '#1a1c1c',
  onSurfaceVariant: '#3e4941',
  inverseSurface: '#2f3131',
  inverseOnSurface: '#f0f1f1',

  // Outline
  outline: '#6e7a70',
  outlineVariant: '#bdcabe',

  // Primary (deep green — main brand)
  primary: '#00643a',
  onPrimary: '#ffffff',
  primaryContainer: '#00804c',
  onPrimaryContainer: '#d1ffdd',
  inversePrimary: '#75db9e',
  primaryFixed: '#91f8b8',
  primaryFixedDim: '#75db9e',
  onPrimaryFixed: '#002110',
  onPrimaryFixedVariant: '#00522f',

  // Secondary (warm stone)
  secondary: '#635e53',
  onSecondary: '#ffffff',
  secondaryContainer: '#e9e2d3',
  onSecondaryContainer: '#696458',
  secondaryFixed: '#e9e2d3',
  secondaryFixedDim: '#cdc6b8',
  onSecondaryFixed: '#1e1b13',
  onSecondaryFixedVariant: '#4b463c',

  // Tertiary (neutral gray)
  tertiary: '#575757',
  onTertiary: '#ffffff',
  tertiaryContainer: '#706f6f',
  onTertiaryContainer: '#f6f3f3',
  tertiaryFixed: '#e4e2e1',
  tertiaryFixedDim: '#c8c6c6',
  onTertiaryFixed: '#1b1c1c',
  onTertiaryFixedVariant: '#474747',

  // Error
  error: '#ba1a1a',
  onError: '#ffffff',
  errorContainer: '#ffdad6',
  onErrorContainer: '#93000a',

  // Background
  background: '#f9f9f9',
  onBackground: '#1a1c1c',

  // Surface variant
  surfaceVariant: '#e2e2e2',

  // Surface tint
  surfaceTint: '#006d40',

  // Semantic extras used in Stitch screens
  // Header brand color (deep maroon/red from HTML — intentional heritage accent)
  brandRed: '#7f1d1d',

  // WhatsApp
  whatsappGreen: '#25D366',
  whatsappTeal: '#128C7E',
  whatsappBubble: '#DCF8C6',

  // Beige surface (used in product selection)
  beigeSurface: '#FDF5E6',

  // Status colors
  success: '#166534',
  successBg: '#f0fdf4',
  warning: '#92400e',
  warningBg: '#fffbeb',
} as const;

export type ColorKey = keyof typeof Colors;
