// Typography scale from heritage_refined/DESIGN.md
// Font: Manrope (all weights)

export const Typography = {
  headlineXl: {
    fontFamily: 'Manrope_700Bold',
    fontSize: 40,
    lineHeight: 48,
    letterSpacing: -0.8, // -0.02em at 40px
  },
  headlineLg: {
    fontFamily: 'Manrope_600SemiBold',
    fontSize: 32,
    lineHeight: 40,
    letterSpacing: -0.32, // -0.01em at 32px
  },
  headlineMd: {
    fontFamily: 'Manrope_600SemiBold',
    fontSize: 24,
    lineHeight: 32,
  },
  bodyLg: {
    fontFamily: 'Manrope_400Regular',
    fontSize: 18,
    lineHeight: 28,
  },
  bodyMd: {
    fontFamily: 'Manrope_400Regular',
    fontSize: 16,
    lineHeight: 24,
  },
  labelLg: {
    fontFamily: 'Manrope_600SemiBold',
    fontSize: 14,
    lineHeight: 20,
    letterSpacing: 0.7, // 0.05em at 14px
  },
  labelSm: {
    fontFamily: 'Manrope_500Medium',
    fontSize: 12,
    lineHeight: 16,
    letterSpacing: 0.36, // 0.03em at 12px
  },
} as const;
