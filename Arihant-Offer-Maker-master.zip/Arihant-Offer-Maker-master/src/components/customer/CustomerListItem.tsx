import React from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';
import type { Customer } from '../../types';
import { Colors } from '../../constants/Colors';
import { Typography } from '../../constants/Typography';
import { BorderRadius, Spacing } from '../../constants/Layout';
import { Badge } from '../ui/Badge';

interface CustomerListItemProps {
  customer: Customer;
  isSelected?: boolean;
  onToggle?: () => void;
  /** Show as a selectable row (share screen) or a full card (customers screen) */
  mode?: 'select' | 'card';
}

const TIER_VARIANT: Record<string, any> = {
  Regular: 'neutral',
  Gold: 'gold',
  Platinum: 'platinum',
  'VIP Bridal': 'primary',
};

/**
 * Customer list item.
 * Supports two modes:
 * - 'select' — compact row with checkbox (share_to_whatsapp screen)
 * - 'card'   — full card with spend stats (customers screen)
 */
export function CustomerListItem({ customer, isSelected = false, onToggle, mode = 'select' }: CustomerListItemProps) {
  const initials = customer.name
    .split(' ')
    .map((w) => w[0])
    .slice(0, 2)
    .join('');

  if (mode === 'select') {
    return (
      <TouchableOpacity style={styles.row} onPress={onToggle} activeOpacity={0.85}>
        {/* Checkbox */}
        <View style={[styles.checkbox, isSelected && styles.checkboxChecked]}>
          {isSelected && <Text style={styles.checkmark}>✓</Text>}
        </View>

        {/* Name / phone */}
        <View style={styles.rowInfo}>
          <Text style={styles.rowName}>{customer.name}</Text>
          <Text style={styles.rowPhone}>{customer.phone}</Text>
        </View>

        {/* Tier */}
        <Badge label={customer.tier} variant={TIER_VARIANT[customer.tier]} />
      </TouchableOpacity>
    );
  }

  // Full card mode
  return (
    <TouchableOpacity style={styles.card} onPress={onToggle} activeOpacity={0.9}>
      {/* Header */}
      <View style={styles.cardHeader}>
        {/* Avatar */}
        <View style={styles.avatarWrap}>
          {customer.avatarUri ? (
            <Image source={{ uri: customer.avatarUri }} style={styles.avatar} />
          ) : (
            <View style={[styles.avatar, styles.avatarPlaceholder]}>
              <Text style={styles.initials}>{initials}</Text>
            </View>
          )}
        </View>

        <View style={styles.cardInfo}>
          <Text style={styles.cardName}>{customer.name}</Text>
          <Text style={styles.cardPhone}>{customer.phone}</Text>
        </View>

        <View style={styles.cardBadges}>
          <Badge label={customer.segment} variant="neutral" />
          <View style={styles.optInRow}>
            <Text style={customer.whatsappOptIn ? styles.optInOn : styles.optInOff}>
              {customer.whatsappOptIn ? '✓ WA' : '✗ WA'}
            </Text>
          </View>
        </View>
      </View>

      {/* Stats */}
      <View style={styles.statsRow}>
        <View style={styles.stat}>
          <Text style={styles.statLabel}>TOTAL SPENT</Text>
          <Text style={styles.statValue}>
            ₹{customer.totalSpent.toLocaleString('en-IN')}
          </Text>
        </View>
        <View style={styles.stat}>
          <Text style={styles.statLabel}>LAST VISIT</Text>
          <Text style={styles.statValue}>
            {new Date(customer.lastVisit).toLocaleDateString('en-IN', {
              day: 'numeric', month: 'short', year: '2-digit',
            })}
          </Text>
        </View>
      </View>

      {/* Footer */}
      <View style={styles.cardFooter}>
        <Badge label={customer.tier} variant={TIER_VARIANT[customer.tier]} />
        <Text style={styles.viewProfile}>View Profile →</Text>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  // Select mode (row)
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.surfaceContainerLowest,
    borderRadius: BorderRadius.xl,
    borderWidth: 1,
    borderColor: Colors.outlineVariant,
    padding: Spacing.md,
    marginBottom: Spacing.sm,
    gap: Spacing.md,
  },
  checkbox: {
    width: 22,
    height: 22,
    borderRadius: 6,
    borderWidth: 2,
    borderColor: Colors.outline,
    alignItems: 'center',
    justifyContent: 'center',
  },
  checkboxChecked: {
    backgroundColor: Colors.primary,
    borderColor: Colors.primary,
  },
  checkmark: { color: Colors.onPrimary, fontSize: 13, fontWeight: 'bold' },
  rowInfo: { flex: 1 },
  rowName: { ...Typography.labelLg, color: Colors.onSurface },
  rowPhone: { ...Typography.labelSm, color: Colors.onSurfaceVariant, marginTop: 2 },

  // Card mode
  card: {
    backgroundColor: Colors.surfaceContainerLowest,
    borderRadius: BorderRadius.xl,
    borderWidth: 1,
    borderColor: Colors.outlineVariant,
    padding: Spacing.lg,
    marginBottom: Spacing.md,
    gap: Spacing.sm,
  },
  cardHeader: { flexDirection: 'row', alignItems: 'flex-start', gap: Spacing.md },
  avatarWrap: {},
  avatar: { width: 56, height: 56, borderRadius: 28 },
  avatarPlaceholder: {
    backgroundColor: Colors.secondaryContainer,
    alignItems: 'center',
    justifyContent: 'center',
  },
  initials: { ...Typography.headlineMd, color: Colors.primary, fontSize: 18 },
  cardInfo: { flex: 1 },
  cardName: { ...Typography.bodyLg, color: Colors.primary, fontWeight: '600' },
  cardPhone: { ...Typography.labelSm, color: Colors.onSurfaceVariant, marginTop: 2 },
  cardBadges: { alignItems: 'flex-end', gap: 4 },
  optInRow: {},
  optInOn: { ...Typography.labelSm, color: Colors.success, fontWeight: '700', fontSize: 10 },
  optInOff: { ...Typography.labelSm, color: Colors.onSurfaceVariant, fontSize: 10 },

  statsRow: {
    flexDirection: 'row',
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: Colors.surfaceContainerHigh,
    paddingVertical: Spacing.sm,
    gap: Spacing.lg,
  },
  stat: { flex: 1 },
  statLabel: { ...Typography.labelSm, color: Colors.onSurfaceVariant, fontSize: 9 },
  statValue: { ...Typography.labelLg, color: Colors.primary, fontSize: 13 },

  cardFooter: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  viewProfile: { ...Typography.labelSm, color: Colors.primary, fontWeight: '700' },
});
