import React from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';
import type { Offer } from '../../types';
import { Colors } from '../../constants/Colors';
import { Typography } from '../../constants/Typography';
import { BorderRadius, Spacing } from '../../constants/Layout';
import { formatRupees } from '../../utils/currency';
import { Badge } from '../ui/Badge';

interface OfferCardProps {
  offer: Offer;
  onDuplicate?: () => void;
  onPress?: () => void;
}

// Status → badge variant
const STATUS_VARIANT = {
  sent: 'success',
  active: 'success',
  scheduled: 'warning',
  draft: 'neutral',
  ended: 'neutral',
} as const;

/**
 * Offer history card — mirrors sent_offers_history/code.html cards.
 * Shows title, stats (delivered/opened), duplicate action.
 */
export function OfferCard({ offer, onDuplicate, onPress }: OfferCardProps) {
  const openRate =
    offer.deliveredCount && offer.deliveredCount > 0 && offer.openedCount
      ? Math.round((offer.openedCount / offer.deliveredCount) * 100)
      : null;

  const statusLabel =
    offer.status === 'sent' ? 'Delivered' :
    offer.status === 'active' ? 'Active' :
    offer.status === 'scheduled' ? 'Scheduled' :
    offer.status === 'draft' ? 'Draft' : 'Ended';

  return (
    <TouchableOpacity style={styles.card} onPress={onPress} activeOpacity={0.9}>
      {/* Header row */}
      <View style={styles.header}>
        <View style={styles.iconBox}>
          <Text style={styles.iconText}>🎉</Text>
        </View>
        <View style={styles.statusCol}>
          <Badge label={statusLabel} variant={STATUS_VARIANT[offer.status] as any} />
          <Text style={styles.date}>
            {new Date(offer.updatedAt).toLocaleDateString('en-IN', {
              day: 'numeric', month: 'short',
            })}
          </Text>
        </View>
      </View>

      {/* Title & description */}
      <Text style={styles.title} numberOfLines={2}>{offer.title}</Text>
      <Text style={styles.description} numberOfLines={1}>{offer.description}</Text>

      {/* Stats */}
      {(offer.deliveredCount !== undefined || offer.openedCount !== undefined) && (
        <View style={styles.statsRow}>
          <View style={styles.statCol}>
            <Text style={styles.statLabel}>DELIVERED</Text>
            <Text style={styles.statValue}>
              {offer.deliveredCount?.toLocaleString('en-IN') ?? '—'}
            </Text>
          </View>
          <View style={styles.statCol}>
            <Text style={styles.statLabel}>OPENED</Text>
            <Text style={styles.statValue}>
              {offer.openedCount?.toLocaleString('en-IN') ?? '—'}
              {openRate !== null && (
                <Text style={styles.statRate}> ({openRate}%)</Text>
              )}
            </Text>
          </View>
        </View>
      )}

      {/* Actions */}
      <View style={styles.actions}>
        <TouchableOpacity style={styles.duplicateBtn} onPress={onDuplicate}>
          <Text style={styles.duplicateText}>⧉  Duplicate</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.moreBtn}>
          <Text style={styles.moreIcon}>⋮</Text>
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: Colors.surfaceContainerLowest,
    borderRadius: BorderRadius.xl,
    borderWidth: 1,
    borderColor: Colors.outlineVariant,
    padding: Spacing.lg,
    marginBottom: Spacing.md,
    gap: Spacing.sm,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  iconBox: {
    width: 44,
    height: 44,
    borderRadius: BorderRadius.DEFAULT,
    backgroundColor: '#fef2f2',
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconText: { fontSize: 20 },
  statusCol: { alignItems: 'flex-end', gap: 4 },
  date: { ...Typography.labelSm, color: Colors.onSurfaceVariant },

  title: {
    ...Typography.headlineMd,
    color: Colors.onSurface,
    fontSize: 18,
  },
  description: {
    ...Typography.bodyMd,
    color: Colors.onSurfaceVariant,
  },

  statsRow: {
    flexDirection: 'row',
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: Colors.surfaceContainerHigh,
    paddingVertical: Spacing.sm,
    gap: Spacing.lg,
    marginVertical: Spacing.xs,
  },
  statCol: { flex: 1 },
  statLabel: {
    ...Typography.labelSm,
    color: Colors.onSurfaceVariant,
    marginBottom: 2,
  },
  statValue: {
    ...Typography.headlineMd,
    fontSize: 20,
    color: Colors.onSurface,
  },
  statRate: {
    ...Typography.labelSm,
    color: Colors.success,
  },

  actions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: Spacing.xs,
  },
  duplicateBtn: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  duplicateText: { ...Typography.labelLg, color: Colors.primary },
  moreBtn: { padding: 6 },
  moreIcon: { fontSize: 20, color: Colors.onSurfaceVariant },
});
