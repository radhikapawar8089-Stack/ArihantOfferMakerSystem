import React from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';
import type { Offer } from '../../types';
import { Colors } from '../../constants/Colors';
import { Typography } from '../../constants/Typography';
import { BorderRadius, Spacing } from '../../constants/Layout';
import { formatRupees } from '../../utils/currency';

interface OfferPreviewCardProps {
  offer: Partial<Offer> & {
    title?: string;
    productImageUri?: string;
    productName?: string;
    originalPrice?: number;
    offerPrice?: number;
    discountPercent?: number;
    description?: string;
    validUntil?: string;
    category?: string;
  };
}

/**
 * Offer preview card — mirrors the mobile phone mockup in create_offer/code.html
 * and the main visual card in offer_preview/code.html.
 * Shows what the customer will see.
 */
export function OfferPreviewCard({ offer }: OfferPreviewCardProps) {
  const discount = offer.discountPercent ?? 0;

  return (
    <View style={styles.card}>
      {/* Product image */}
      <View style={styles.imageWrap}>
        {offer.productImageUri ? (
          <Image source={{ uri: offer.productImageUri }} style={styles.image} resizeMode="cover" />
        ) : (
          <View style={styles.imagePlaceholder}>
            <Text style={styles.placeholderIcon}>🧵</Text>
            <Text style={styles.placeholderText}>No image selected</Text>
          </View>
        )}

        {/* Discount badge on image */}
        {discount > 0 && (
          <View style={styles.discountBadge}>
            <Text style={styles.discountLabel}>Save</Text>
            <Text style={styles.discountPercent}>{discount}%</Text>
          </View>
        )}

        {/* Offer type chip */}
        {offer.category && (
          <View style={styles.categoryChip}>
            <Text style={styles.categoryText}>{offer.category.toUpperCase()}</Text>
          </View>
        )}
      </View>

      {/* Content */}
      <View style={styles.content}>
        {offer.category && (
          <Text style={styles.subtitle}>{offer.category}</Text>
        )}

        <Text style={styles.title} numberOfLines={2}>
          {offer.title ?? offer.productName ?? 'Offer Title'}
        </Text>

        {/* Pricing */}
        <View style={styles.priceRow}>
          <Text style={styles.offerPrice}>
            {formatRupees(offer.offerPrice ?? 0)}
          </Text>
          {(offer.originalPrice ?? 0) > 0 && (
            <Text style={styles.originalPrice}>
              {formatRupees(offer.originalPrice ?? 0)}
            </Text>
          )}
        </View>

        {/* Description */}
        {offer.description ? (
          <Text style={styles.description} numberOfLines={3}>
            {offer.description}
          </Text>
        ) : null}

        {/* Validity */}
        {offer.validUntil && (
          <View style={styles.validityBox}>
            <Text style={styles.validityLabel}>VALID UNTIL</Text>
            <Text style={styles.validityValue}>
              {new Date(offer.validUntil).toLocaleDateString('en-IN', {
                day: 'numeric', month: 'short', year: 'numeric',
              })}
            </Text>
          </View>
        )}

        {/* WhatsApp CTA (shown in preview) */}
        <View style={styles.whatsappCta}>
          <Text style={styles.whatsappCtaText}>💬  Inquire on WhatsApp</Text>
        </View>

        {/* Store footer */}
        <View style={styles.storeFooter}>
          <Text style={styles.storeLabel}>Available only at</Text>
          <Text style={styles.storeName}>ARIHANT CLOTH STORE</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: Colors.surfaceContainerLowest,
    borderRadius: BorderRadius.xl,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: Colors.secondaryContainer,
  },
  imageWrap: {
    height: 240,
    position: 'relative',
  },
  image: { width: '100%', height: '100%' },
  imagePlaceholder: {
    flex: 1,
    backgroundColor: Colors.surfaceContainerHigh,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  placeholderIcon: { fontSize: 48 },
  placeholderText: { ...Typography.labelSm, color: Colors.onSurfaceVariant },

  discountBadge: {
    position: 'absolute',
    top: 16,
    left: 16,
    backgroundColor: Colors.primary,
    borderRadius: BorderRadius.DEFAULT,
    paddingHorizontal: 12,
    paddingVertical: 6,
    alignItems: 'center',
  },
  discountLabel: { color: Colors.onPrimary, fontSize: 10, fontWeight: '600', letterSpacing: 1 },
  discountPercent: { color: Colors.onPrimary, fontSize: 22, fontWeight: '800', lineHeight: 26 },

  categoryChip: {
    position: 'absolute',
    top: 12,
    right: 12,
    backgroundColor: Colors.primary,
    borderRadius: BorderRadius.full,
    paddingHorizontal: 10,
    paddingVertical: 4,
  },
  categoryText: { ...Typography.labelSm, color: Colors.onPrimary, fontSize: 9, letterSpacing: 1 },

  content: {
    padding: Spacing.lg,
    gap: Spacing.sm,
  },
  subtitle: { ...Typography.labelSm, color: Colors.secondary, letterSpacing: 1 },
  title: { ...Typography.headlineMd, color: Colors.primary, lineHeight: 30 },

  priceRow: { flexDirection: 'row', alignItems: 'baseline', gap: 10 },
  offerPrice: { ...Typography.headlineMd, color: Colors.primary, fontWeight: '800', fontSize: 28 },
  originalPrice: {
    ...Typography.bodyMd,
    color: Colors.onSurfaceVariant,
    textDecorationLine: 'line-through',
  },

  description: {
    ...Typography.bodyMd,
    color: Colors.onSurfaceVariant,
    fontSize: 13,
    lineHeight: 19,
  },

  validityBox: {
    backgroundColor: Colors.surfaceContainerLow,
    borderRadius: BorderRadius.DEFAULT,
    borderWidth: 1,
    borderColor: Colors.outlineVariant,
    padding: Spacing.sm,
  },
  validityLabel: { ...Typography.labelSm, color: Colors.secondary, fontSize: 9, letterSpacing: 1 },
  validityValue: { ...Typography.labelLg, color: Colors.onSurface, marginTop: 2 },

  whatsappCta: {
    backgroundColor: Colors.whatsappGreen,
    borderRadius: BorderRadius.xl,
    paddingVertical: 12,
    alignItems: 'center',
  },
  whatsappCtaText: { color: '#fff', fontWeight: '700', fontSize: 14 },

  storeFooter: { alignItems: 'center', paddingTop: Spacing.sm },
  storeLabel: { ...Typography.labelSm, color: Colors.secondary, letterSpacing: 1 },
  storeName: { ...Typography.headlineMd, color: Colors.primaryContainer, fontSize: 16, letterSpacing: 2 },
});
