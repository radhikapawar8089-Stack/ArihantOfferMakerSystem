import React from 'react';
import {
  TouchableOpacity,
  View,
  Text,
  StyleSheet,
} from 'react-native';
import type { OfferTypeConfig } from '../../types';
import { Colors } from '../../constants/Colors';
import { Typography } from '../../constants/Typography';
import { BorderRadius, Spacing } from '../../constants/Layout';

interface OfferTypeCardProps {
  config: OfferTypeConfig;
  isSelected: boolean;
  onPress: () => void;
}

// Icon map (emoji stand-ins until a vector icon lib is configured)
const ICON_MAP: Record<string, string> = {
  schedule: '⏰',
  calendar_view_week: '📅',
  calendar_month: '🗓️',
};

/**
 * Offer type selection card — mirrors select_offer_type/code.html radio cards.
 * Shows Daily / Weekly / Monthly with description and optional "Best Value" badge.
 */
export function OfferTypeCard({ config, isSelected, onPress }: OfferTypeCardProps) {
  return (
    <TouchableOpacity
      style={[styles.card, isSelected && styles.cardSelected]}
      onPress={onPress}
      activeOpacity={0.8}
      accessibilityRole="radio"
      accessibilityState={{ selected: isSelected }}
    >
      {/* Best Value badge */}
      {config.badge && (
        <View style={styles.badgeWrap}>
          <Text style={styles.badge}>{config.badge.toUpperCase()}</Text>
        </View>
      )}

      {/* Icon */}
      <View style={[styles.iconBox, isSelected && styles.iconBoxActive]}>
        <Text style={styles.iconText}>{ICON_MAP[config.icon] ?? '📌'}</Text>
      </View>

      {/* Label */}
      <Text style={[styles.title, isSelected && styles.titleActive]}>
        {config.label}
      </Text>

      {/* Description */}
      <Text style={styles.description}>{config.description}</Text>

      {/* Footer */}
      <View style={styles.footer}>
        <Text style={[styles.selectText, isSelected && styles.selectTextActive]}>
          {isSelected ? '✓ Selected' : 'Select Plan →'}
        </Text>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: Colors.surfaceContainerLowest,
    borderRadius: BorderRadius.xl,
    borderWidth: 1.5,
    borderColor: Colors.outlineVariant,
    padding: Spacing.lg,
    marginBottom: Spacing.md,
    overflow: 'hidden',
    position: 'relative',
  },
  cardSelected: {
    borderColor: Colors.primaryContainer,
    backgroundColor: Colors.secondaryContainer + '33', // ~20% opacity
  },
  badgeWrap: {
    position: 'absolute',
    top: 0,
    right: 0,
    backgroundColor: Colors.primary,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderBottomLeftRadius: BorderRadius.DEFAULT,
  },
  badge: {
    ...Typography.labelSm,
    color: Colors.onPrimary,
    fontSize: 9,
    letterSpacing: 1,
  },
  iconBox: {
    width: 48,
    height: 48,
    borderRadius: BorderRadius.DEFAULT,
    backgroundColor: '#fef2f2',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Spacing.sm,
  },
  iconBoxActive: {
    backgroundColor: Colors.secondaryContainer,
  },
  iconText: {
    fontSize: 22,
  },
  title: {
    ...Typography.headlineMd,
    color: Colors.onSurface,
    marginBottom: Spacing.xs,
  },
  titleActive: {
    color: Colors.primary,
  },
  description: {
    ...Typography.bodyMd,
    color: Colors.onSurfaceVariant,
    marginBottom: Spacing.lg,
    lineHeight: 22,
  },
  footer: {
    marginTop: 'auto',
  },
  selectText: {
    ...Typography.labelLg,
    color: Colors.primary,
  },
  selectTextActive: {
    color: Colors.primaryContainer,
    fontWeight: '800',
  },
});
