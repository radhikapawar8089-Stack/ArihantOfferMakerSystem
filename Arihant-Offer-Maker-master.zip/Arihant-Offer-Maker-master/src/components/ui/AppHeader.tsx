import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  StatusBar,
  Platform,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Colors } from '../../constants/Colors';
import { Typography } from '../../constants/Typography';
import { Layout } from '../../constants/Layout';

interface AppHeaderProps {
  title?: string;
  /** Show a back arrow instead of hamburger */
  showBack?: boolean;
  /** Called when the left icon is pressed */
  onLeftPress?: () => void;
  /** Right-side element (avatar or icon button) */
  rightElement?: React.ReactNode;
}

/**
 * Shared top app bar used across all screens.
 * Mirrors the fixed header from every Stitch HTML screen.
 */
export function AppHeader({
  title = 'Arihant Cloth Store',
  showBack = false,
  onLeftPress,
  rightElement,
}: AppHeaderProps) {
  const insets = useSafeAreaInsets();

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <View style={styles.inner}>
        {/* Left: menu or back */}
        <View style={styles.left}>
          <TouchableOpacity
            style={styles.iconBtn}
            onPress={onLeftPress}
            accessibilityRole="button"
            accessibilityLabel={showBack ? 'Go back' : 'Open menu'}
          >
            <Text style={styles.icon}>{showBack ? '←' : '☰'}</Text>
          </TouchableOpacity>
          <Text style={styles.title} numberOfLines={1}>
            {title.toUpperCase()}
          </Text>
        </View>

        {/* Right: slot for avatar or action */}
        {rightElement && <View style={styles.right}>{rightElement}</View>}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: Colors.surfaceContainerLowest,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: Colors.outlineVariant,
    // Shadow
    ...Platform.select({
      ios: { shadowColor: '#000', shadowOpacity: 0.06, shadowRadius: 4, shadowOffset: { width: 0, height: 2 } },
      android: { elevation: 3 },
    }),
  },
  inner: {
    height: Layout.headerHeight,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Layout.marginMobile,
  },
  left: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flex: 1,
  },
  iconBtn: {
    padding: 8,
    borderRadius: 20,
  },
  icon: {
    fontSize: 20,
    color: Colors.brandRed,
  },
  title: {
    ...Typography.labelLg,
    color: Colors.brandRed,
    letterSpacing: 2,
    flexShrink: 1,
  },
  right: {
    marginLeft: 8,
  },
});
