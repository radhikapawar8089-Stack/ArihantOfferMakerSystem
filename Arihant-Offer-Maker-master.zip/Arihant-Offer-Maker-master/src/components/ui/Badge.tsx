import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Colors } from '../../constants/Colors';
import { Typography } from '../../constants/Typography';
import { BorderRadius } from '../../constants/Layout';

type BadgeVariant = 'success' | 'warning' | 'error' | 'primary' | 'neutral' | 'gold' | 'platinum';

interface BadgeProps {
  label: string;
  variant?: BadgeVariant;
  uppercase?: boolean;
}

/**
 * Status badge used for tier labels (Platinum/Gold/Regular),
 * offer status (Active/Ended/Delivered), and WhatsApp opt-in.
 */
export function Badge({ label, variant = 'neutral', uppercase = true }: BadgeProps) {
  return (
    <View style={[styles.base, styles[variant]]}>
      <Text style={[styles.text, styles[`${variant}Text`]]}>
        {uppercase ? label.toUpperCase() : label}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  base: {
    paddingHorizontal: 10,
    paddingVertical: 3,
    borderRadius: BorderRadius.full,
    alignSelf: 'flex-start',
  },
  text: {
    ...Typography.labelSm,
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 0.8,
  },

  // Variants
  success: { backgroundColor: Colors.successBg },
  successText: { color: Colors.success },

  warning: { backgroundColor: Colors.warningBg },
  warningText: { color: Colors.warning },

  error: { backgroundColor: Colors.errorContainer },
  errorText: { color: Colors.onErrorContainer },

  primary: { backgroundColor: Colors.primary },
  primaryText: { color: Colors.onPrimary },

  neutral: { backgroundColor: Colors.surfaceContainerHigh },
  neutralText: { color: Colors.onSurfaceVariant },

  gold: { backgroundColor: '#fffbeb', borderWidth: 1, borderColor: '#d97706' },
  goldText: { color: '#92400e' },

  platinum: { backgroundColor: '#fef2f2', borderWidth: 1, borderColor: '#ef4444' },
  platinumText: { color: '#7f1d1d' },
});
