import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Image,
} from 'react-native';
import type { BottomTabBarProps } from '@react-navigation/bottom-tabs';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Colors } from '../../constants/Colors';
import { Typography } from '../../constants/Typography';
import { BorderRadius, Layout } from '../../constants/Layout';

// Tab icon map (using emoji as stand-in for Material Symbols)
// TODO: Replace with @expo/vector-icons or custom icon font
const TAB_ICONS: Record<string, { default: string; active: string }> = {
  index:     { default: '⊞', active: '⊞' },
  history:   { default: '📋', active: '📋' },
  customers: { default: '👥', active: '👥' },
  settings:  { default: '⚙', active: '⚙' },
};

const TAB_LABELS: Record<string, string> = {
  index:     'Home',
  history:   'Offers',
  customers: 'Customers',
  settings:  'Settings',
};

/**
 * Custom bottom tab bar.
 * Mirrors the fixed bottom nav from all Stitch screens:
 * Home | Offers | Customers | Settings
 */
export function BottomTabBar({ state, descriptors, navigation }: BottomTabBarProps) {
  const insets = useSafeAreaInsets();

  return (
    <View style={[styles.container, { paddingBottom: insets.bottom }]}>
      {state.routes.map((route, index) => {
        const isFocused = state.index === index;
        const label = TAB_LABELS[route.name] ?? route.name;
        const icons = TAB_ICONS[route.name] ?? { default: '•', active: '●' };

        const onPress = () => {
          const event = navigation.emit({
            type: 'tabPress',
            target: route.key,
            canPreventDefault: true,
          });
          if (!isFocused && !event.defaultPrevented) {
            navigation.navigate(route.name);
          }
        };

        return (
          <TouchableOpacity
            key={route.key}
            style={[styles.tab, isFocused && styles.tabActive]}
            onPress={onPress}
            accessibilityRole="tab"
            accessibilityLabel={label}
            accessibilityState={{ selected: isFocused }}
          >
            <Text style={[styles.icon, isFocused && styles.iconActive]}>
              {isFocused ? icons.active : icons.default}
            </Text>
            <Text style={[styles.label, isFocused && styles.labelActive]}>
              {label}
            </Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    backgroundColor: Colors.surfaceContainerLowest,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: Colors.outlineVariant,
    paddingTop: 8,
    minHeight: Layout.bottomTabHeight,
  },
  tab: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 6,
    borderRadius: BorderRadius.DEFAULT,
    marginHorizontal: 4,
  },
  tabActive: {
    backgroundColor: '#fef2f2', // red-50 from Stitch
  },
  icon: {
    fontSize: 20,
    color: Colors.onSurfaceVariant,
    marginBottom: 2,
  },
  iconActive: {
    color: Colors.brandRed,
  },
  label: {
    ...Typography.labelSm,
    fontSize: 11,
    color: Colors.onSurfaceVariant,
  },
  labelActive: {
    color: Colors.brandRed,
    fontWeight: '700',
  },
});
