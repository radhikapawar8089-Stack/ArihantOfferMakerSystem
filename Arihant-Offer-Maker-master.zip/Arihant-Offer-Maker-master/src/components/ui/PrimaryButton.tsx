import React from 'react';
import {
  TouchableOpacity,
  Text,
  StyleSheet,
  ActivityIndicator,
  View,
  type StyleProp,
  type ViewStyle,
} from 'react-native';
import { Colors } from '../../constants/Colors';
import { Typography } from '../../constants/Typography';
import { BorderRadius } from '../../constants/Layout';

interface PrimaryButtonProps {
  label: string;
  onPress: () => void;
  isLoading?: boolean;
  disabled?: boolean;
  variant?: 'primary' | 'whatsapp' | 'outline' | 'ghost';
  style?: StyleProp<ViewStyle>;
  icon?: string; // simple emoji / symbol character
}

/**
 * Reusable CTA button.
 * Variants mirror the button types across all Stitch screens.
 */
export function PrimaryButton({
  label,
  onPress,
  isLoading = false,
  disabled = false,
  variant = 'primary',
  style,
  icon,
}: PrimaryButtonProps) {
  const isDisabled = disabled || isLoading;

  return (
    <TouchableOpacity
      style={[styles.base, styles[variant], isDisabled && styles.disabled, style]}
      onPress={onPress}
      disabled={isDisabled}
      activeOpacity={0.85}
      accessibilityRole="button"
    >
      {isLoading ? (
        <ActivityIndicator
          color={variant === 'outline' || variant === 'ghost' ? Colors.primary : Colors.onPrimary}
          size="small"
        />
      ) : (
        <View style={styles.row}>
          {icon && <Text style={[styles.icon, styles[`${variant}Text`]]}>{icon}</Text>}
          <Text style={[styles.label, styles[`${variant}Text`]]}>{label}</Text>
        </View>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  base: {
    height: 52,
    borderRadius: BorderRadius.lg,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 24,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  icon: {
    fontSize: 18,
  },
  label: {
    ...Typography.labelLg,
    fontSize: 15,
  },

  // Variants
  primary: {
    backgroundColor: Colors.primary,
  },
  primaryText: {
    color: Colors.onPrimary,
  },

  whatsapp: {
    backgroundColor: Colors.whatsappGreen,
  },
  whatsappText: {
    color: '#fff',
  },

  outline: {
    backgroundColor: 'transparent',
    borderWidth: 1.5,
    borderColor: Colors.primary,
  },
  outlineText: {
    color: Colors.primary,
  },

  ghost: {
    backgroundColor: 'transparent',
  },
  ghostText: {
    color: Colors.primary,
  },

  disabled: {
    opacity: 0.5,
  },
});
