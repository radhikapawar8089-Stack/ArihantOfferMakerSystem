import React from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';
import type { Product } from '../../types';
import { Colors } from '../../constants/Colors';
import { Typography } from '../../constants/Typography';
import { BorderRadius, Spacing } from '../../constants/Layout';
import { formatRupees } from '../../utils/currency';

interface ProductCardProps {
  product: Product;
  isSelected?: boolean;
  onSelect: () => void;
  /** 'large' for the featured card, 'standard' for grid items */
  size?: 'large' | 'standard';
}

/**
 * Product card — mirrors select_product/code.html grid items.
 * Featured (large) card uses 16:9 image. Standard uses 1:1.
 */
export function ProductCard({ product, isSelected = false, onSelect, size = 'standard' }: ProductCardProps) {
  return (
    <TouchableOpacity
      style={[styles.card, isSelected && styles.cardSelected, size === 'large' && styles.cardLarge]}
      onPress={onSelect}
      activeOpacity={0.9}
      accessibilityRole="button"
      accessibilityLabel={`Select ${product.name}`}
      accessibilityState={{ selected: isSelected }}
    >
      {/* Image */}
      <View style={size === 'large' ? styles.imageLarge : styles.imageStandard}>
        {product.imageUri ? (
          <Image
            source={{ uri: product.imageUri }}
            style={styles.image}
            resizeMode="cover"
          />
        ) : (
          <View style={styles.imagePlaceholder}>
            <Text style={styles.placeholderIcon}>🧵</Text>
          </View>
        )}

        {/* Selection checkmark */}
        {isSelected && (
          <View style={styles.checkOverlay}>
            <Text style={styles.checkIcon}>✓</Text>
          </View>
        )}
      </View>

      {/* Details */}
      <View style={styles.details}>
        {product.badge && (
          <View style={styles.badgeWrap}>
            <Text style={styles.badgeText}>{product.badge.toUpperCase()}</Text>
          </View>
        )}
        <Text style={styles.name} numberOfLines={size === 'large' ? 2 : 1}>
          {product.name}
        </Text>
        {size === 'large' && product.description && (
          <Text style={styles.description} numberOfLines={2}>{product.description}</Text>
        )}
        <View style={styles.footer}>
          <Text style={styles.price}>{formatRupees(product.price)}</Text>
          <TouchableOpacity
            style={[styles.selectBtn, isSelected && styles.selectBtnActive]}
            onPress={onSelect}
          >
            <Text style={[styles.selectBtnText, isSelected && styles.selectBtnTextActive]}>
              {isSelected ? '✓ Selected' : 'Select'}
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: Colors.surfaceContainerLowest,
    borderRadius: BorderRadius.xl,
    borderWidth: 1,
    borderColor: Colors.outlineVariant,
    overflow: 'hidden',
    marginBottom: Spacing.md,
  },
  cardSelected: {
    borderColor: Colors.primaryContainer,
    borderWidth: 2,
  },
  cardLarge: {},

  imageLarge: { height: 200, width: '100%' },
  imageStandard: { aspectRatio: 1, width: '100%' },
  image: { width: '100%', height: '100%' },
  imagePlaceholder: {
    flex: 1,
    backgroundColor: Colors.surfaceContainerHigh,
    alignItems: 'center',
    justifyContent: 'center',
  },
  placeholderIcon: { fontSize: 40 },
  checkOverlay: {
    position: 'absolute',
    top: 8,
    right: 8,
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: Colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  checkIcon: { color: Colors.onPrimary, fontSize: 18, fontWeight: 'bold' },

  details: {
    padding: Spacing.md,
    alignItems: 'center',
    gap: 6,
  },
  badgeWrap: {
    backgroundColor: Colors.secondaryContainer,
    borderRadius: BorderRadius.full,
    paddingHorizontal: 10,
    paddingVertical: 2,
  },
  badgeText: {
    ...Typography.labelSm,
    fontSize: 9,
    color: Colors.onSecondaryContainer,
    letterSpacing: 0.8,
  },
  name: {
    ...Typography.labelLg,
    color: Colors.onSurface,
    textAlign: 'center',
  },
  description: {
    ...Typography.bodyMd,
    color: Colors.onSurfaceVariant,
    fontSize: 13,
    textAlign: 'center',
  },
  footer: {
    width: '100%',
    alignItems: 'center',
    gap: 8,
    marginTop: 4,
  },
  price: {
    ...Typography.headlineMd,
    fontSize: 18,
    color: Colors.primary,
    fontWeight: '700',
  },
  selectBtn: {
    width: '100%',
    height: 40,
    borderRadius: BorderRadius.DEFAULT,
    borderWidth: 1.5,
    borderColor: Colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  selectBtnActive: {
    backgroundColor: Colors.primary,
  },
  selectBtnText: {
    ...Typography.labelLg,
    color: Colors.primary,
  },
  selectBtnTextActive: {
    color: Colors.onPrimary,
  },
});
