import { Linking, Alert } from 'react-native';
import type { Offer } from '../types';
import { MOCK_TEMPLATES } from './mockData';

/**
 * Build a WhatsApp share message from an offer and template.
 * TODO: Replace with WhatsApp Business API when credentials are available.
 */
export function buildWhatsAppMessage(offer: Offer, templateId = 't1'): string {
  const template = MOCK_TEMPLATES.find((t) => t.id === templateId) ?? MOCK_TEMPLATES[0];

  return template.body
    .replace(/{{productName}}/g, offer.productName)
    .replace(/{{originalPrice}}/g, offer.originalPrice.toLocaleString('en-IN'))
    .replace(/{{offerPrice}}/g, offer.offerPrice.toLocaleString('en-IN'))
    .replace(/{{discountPercent}}/g, String(offer.discountPercent))
    .replace(
      /{{validUntil}}/g,
      new Date(offer.validUntil).toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
      })
    );
}

/**
 * Open WhatsApp with a pre-filled message to a specific phone number.
 * Uses the wa.me deep-link scheme.
 *
 * TODO: For bulk sending, integrate WhatsApp Business API (Cloud API).
 */
export async function sendWhatsAppToNumber(
  phone: string,
  message: string
): Promise<void> {
  // Strip formatting from phone: "+91 98765 43210" → "919876543210"
  const cleaned = phone.replace(/\D/g, '');
  const encoded = encodeURIComponent(message);
  const url = `https://wa.me/${cleaned}?text=${encoded}`;

  const canOpen = await Linking.canOpenURL(url);
  if (!canOpen) {
    Alert.alert(
      'WhatsApp not found',
      'Please install WhatsApp to send offers directly.',
      [{ text: 'OK' }]
    );
    return;
  }
  await Linking.openURL(url);
}

/**
 * Open the generic WhatsApp share sheet (no specific recipient).
 * Useful when sharing to broadcast lists.
 *
 * TODO: Replace with WhatsApp Business API broadcast endpoint.
 */
export async function shareViaWhatsApp(message: string): Promise<void> {
  const encoded = encodeURIComponent(message);
  const url = `https://wa.me/?text=${encoded}`;

  const canOpen = await Linking.canOpenURL(url);
  if (!canOpen) {
    Alert.alert('WhatsApp not found', 'Please install WhatsApp on this device.');
    return;
  }
  await Linking.openURL(url);
}
