import { create } from 'zustand';
import type { DraftOffer, OfferType } from '../types';
import type { Product } from '../types/product';
import { calcDiscountPercent } from '../utils/discount';

interface OfferCreationState {
  draft: DraftOffer;
  // Step actions
  setOfferType: (type: OfferType) => void;
  setProduct: (product: Product) => void;
  setFormFields: (fields: Partial<DraftOffer>) => void;
  resetDraft: () => void;
  // Computed getter
  discountPercent: () => number;
}

const EMPTY_DRAFT: DraftOffer = {};

export const useOfferStore = create<OfferCreationState>((set, get) => ({
  draft: EMPTY_DRAFT,

  setOfferType: (type) =>
    set((state) => ({ draft: { ...state.draft, offerType: type } })),

  setProduct: (product) =>
    set((state) => ({
      draft: {
        ...state.draft,
        product,
        productId: product.id,
        productName: product.name,
        productImageUri: product.imageUri,
        category: product.category,
      },
    })),

  setFormFields: (fields) =>
    set((state) => ({ draft: { ...state.draft, ...fields } })),

  resetDraft: () => set({ draft: EMPTY_DRAFT }),

  discountPercent: () => {
    const { originalPrice, offerPrice } = get().draft;
    if (!originalPrice || !offerPrice) return 0;
    return calcDiscountPercent(originalPrice, offerPrice);
  },
}));
