import { create } from 'zustand';

interface AuthUser {
  mobile: string;
  name: string;
  staffId: string;
  avatarUri?: string;
}

interface AuthState {
  isAuthenticated: boolean;
  user: AuthUser | null;
  isLoading: boolean;
  // Actions
  login: (mobile: string) => Promise<void>;
  verifyOtp: (otp: string) => Promise<boolean>;
  logout: () => void;
}

// TODO: Replace mock auth with real OTP service (Firebase Auth / custom backend)
export const useAuthStore = create<AuthState>((set) => ({
  isAuthenticated: false,
  user: null,
  isLoading: false,

  login: async (mobile: string) => {
    set({ isLoading: true });
    // Mock: simulate sending OTP
    await new Promise((resolve) => setTimeout(resolve, 1000));
    set({ isLoading: false });
    // In real flow, backend sends OTP to mobile
  },

  verifyOtp: async (otp: string) => {
    set({ isLoading: true });
    await new Promise((resolve) => setTimeout(resolve, 800));
    // Mock: any 4-digit OTP succeeds
    const success = otp.length === 4;
    if (success) {
      set({
        isAuthenticated: true,
        user: {
          mobile: '9876543210',
          name: 'Arpit',
          staffId: '#4402',
        },
        isLoading: false,
      });
    } else {
      set({ isLoading: false });
    }
    return success;
  },

  logout: () => {
    set({ isAuthenticated: false, user: null });
  },
}));
