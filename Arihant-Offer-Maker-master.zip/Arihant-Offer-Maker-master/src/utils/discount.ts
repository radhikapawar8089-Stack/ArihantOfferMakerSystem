/**
 * Calculate discount percentage from original and offer price
 * Business rule: offerPrice must be < originalPrice
 */
export function calcDiscountPercent(originalPrice: number, offerPrice: number): number {
  if (originalPrice <= 0 || offerPrice <= 0 || offerPrice >= originalPrice) return 0;
  return Math.round(((originalPrice - offerPrice) / originalPrice) * 100);
}

/**
 * Returns savings amount
 */
export function calcSavings(originalPrice: number, offerPrice: number): number {
  return Math.max(0, originalPrice - offerPrice);
}
