// Utility: format numbers as Indian Rupees (₹)

/**
 * Format a number as ₹ with Indian comma formatting
 * e.g. 14999 → "₹14,999"
 */
export function formatRupees(amount: number): string {
  if (amount === 0) return '₹0';
  return `₹${amount.toLocaleString('en-IN')}`;
}

/**
 * Format rupees with paise (for fractional amounts)
 * e.g. 14999.50 → "₹14,999.50"
 */
export function formatRupeesWithPaise(amount: number): string {
  return `₹${amount.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}
