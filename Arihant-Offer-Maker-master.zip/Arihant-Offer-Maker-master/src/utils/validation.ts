import { z } from 'zod';

// ---------------------------------------------------------------------------
// Offer creation form schema (text inputs coerced to numbers)
// ---------------------------------------------------------------------------
export const createOfferSchema = z
  .object({
    title: z.string().min(3, 'Offer title must be at least 3 characters'),
    description: z.string().max(500, 'Description must be under 500 characters').optional(),
    originalPrice: z
      .string()
      .min(1, 'Original price is required')
      .refine((v) => !isNaN(Number(v)) && Number(v) > 0, 'Enter a valid original price'),
    offerPrice: z
      .string()
      .min(1, 'Offer price is required')
      .refine((v) => !isNaN(Number(v)) && Number(v) > 0, 'Enter a valid offer price'),
    validityDays: z
      .string()
      .optional()
      .refine((v) => !v || (!isNaN(Number(v)) && Number(v) > 0), 'Enter valid number of days'),
  })
  .refine(
    (data) => Number(data.offerPrice) < Number(data.originalPrice),
    { message: 'Offer price must be lower than original price', path: ['offerPrice'] },
  );

export type CreateOfferFormData = z.infer<typeof createOfferSchema>;

// ---------------------------------------------------------------------------
// Login form schema
// ---------------------------------------------------------------------------
export const loginSchema = z.object({
  mobile: z
    .string()
    .length(10, 'Enter a valid 10-digit mobile number')
    .regex(/^[6-9]\d{9}$/, 'Enter a valid Indian mobile number'),
});

export const otpSchema = z.object({
  otp: z
    .string()
    .length(4, 'OTP must be 4 digits')
    .regex(/^\d{4}$/, 'OTP must be numeric'),
});

export type LoginFormData = z.infer<typeof loginSchema>;
export type OtpFormData = z.infer<typeof otpSchema>;
