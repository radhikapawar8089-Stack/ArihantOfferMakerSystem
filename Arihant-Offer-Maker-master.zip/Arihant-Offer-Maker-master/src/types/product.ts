// Product type

export type ProductCategory =
  | 'All Collections'
  | 'Sarees'
  | 'Kurtis'
  | 'Dress Materials'
  | 'Silk Specials'
  | 'Mens Wear'
  | 'Bridal';

export interface Product {
  id: string;
  name: string;
  category: ProductCategory;
  price: number;           // in rupees
  imageUri?: string;
  description?: string;
  badge?: string;          // e.g. "Premium Silk", "New Arrival"
  inStock: boolean;
}
