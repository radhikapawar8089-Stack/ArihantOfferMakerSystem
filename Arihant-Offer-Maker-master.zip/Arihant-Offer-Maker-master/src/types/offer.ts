// Offer types

export type OfferType = 'daily' | 'weekly' | 'monthly';
export type OfferStatus = 'draft' | 'scheduled' | 'sent' | 'active' | 'ended';

export interface OfferTypeConfig {
  type: OfferType;
  label: string;
  description: string;
  icon: string;           // Material Symbol icon name
  durationDays: number;
  badge?: string;
}

export interface Offer {
  id: string;
  title: string;
  category: string;
  productId?: string;
  productName: string;
  productImageUri?: string;
  originalPrice: number;
  offerPrice: number;
  discountPercent: number;  // computed: (originalPrice - offerPrice) / originalPrice * 100
  description: string;
  validFrom: string;        // ISO date string
  validUntil: string;       // ISO date string
  offerType: OfferType;
  status: OfferStatus;
  sentTo?: number;          // number of customers
  deliveredCount?: number;
  openedCount?: number;
  createdAt: string;        // ISO date string
  updatedAt: string;
}

// Partial offer used during the creation flow
export interface DraftOffer {
  offerType?: OfferType;
  productId?: string;
  productName?: string;
  productImageUri?: string;
  product?: import('./product').Product;   // full product ref for display
  title?: string;
  category?: string;
  originalPrice?: number;
  offerPrice?: number;
  description?: string;
  validFrom?: string;
  validUntil?: string;
  validityDays?: number;
}
