// WhatsApp message template types

export interface MessageTemplate {
  id: string;
  name: string;
  body: string;             // Raw template with {{placeholders}}
  isDefault: boolean;
}

export interface ComposedMessage {
  templateId: string;
  body: string;             // Filled template
  imageUri?: string;
  recipientCount: number;
}
