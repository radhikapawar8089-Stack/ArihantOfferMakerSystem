// Customer types

export type CustomerSegment =
  | 'All'
  | 'Women Ethnic'
  | "Men's Wear"
  | 'Bridal Exclusive';

export type CustomerTier = 'Regular' | 'Gold' | 'Platinum' | 'VIP Bridal';

export interface Customer {
  id: string;
  name: string;
  phone: string;            // +91 XXXXX XXXXX
  segment: CustomerSegment;
  tier: CustomerTier;
  whatsappOptIn: boolean;
  totalSpent: number;       // in rupees
  lastVisit: string;        // ISO date string
  avatarUri?: string;
  preferredCategories?: string[];
}
