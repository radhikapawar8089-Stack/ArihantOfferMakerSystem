// Barrel exports for all types
export type { Product, ProductCategory } from './product';
export type {
  OfferType,
  OfferStatus,
  OfferTypeConfig,
  Offer,
  DraftOffer,
} from './offer';
export type {
  Customer,
  CustomerSegment,
  CustomerTier,
} from './customer';
export type { MessageTemplate, ComposedMessage } from './message';
